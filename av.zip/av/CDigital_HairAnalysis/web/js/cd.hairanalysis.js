define([
    "jquery",
    "matchMedia",
	"jquery/ui",
    'jquery/validate',
    "domReady!",
], function($, mediaCheck) {
    "use strict";

    var self = this;

    $.widget('cd.hairanalysis', {
        options: {
            errorMessage : null,
            emailError : null,
            skinConcernError : null,
            stepNameSelector : null,
            stepEmailSelector : null,
            stepCitySelector : null,
            stepZipSelector : null,
            stepGenderSelector : null,
            stepAgeGroupSelector : null,
            stepInput1 : null,
            stepInput2 : null,
            concern : null,
            selector: null,
            stepActive: null,
            stepCount: 0,
            answerSelector: null,
            answers: [],
            requestUrl: null,
            resultPage: null,
            cookieExpiryTime: 5,
            saveResultFormId: null,
            retakeSelector: null,
            retakeUrl: null,
            backButtonSelector: null,
            newsletterSignUpSelector: null,
            onLoad: 0,
            guestSaveUrl: null,
            addTopAllToBag: null,
            addLotionAllToBag: null,
            addCleanserAllToBag: null,
            addToCartUrl: null,
            addToFavoritesUrl: null,
            minicartSelector: '[data-block="minicart"]'
        },

        _create: function () {
            self = this;

        },

        _init: function () {
            self = this;

            if (self.options.selector != null) {
                self._answersSelection();
                self._hairAnlysisSteps();
            }

            if( self.options.retakeSelector ){
                $(self.options.retakeSelector).on('click', function(){
                    self._retakeSkinAnalysis();
                });
            }

            if( self.options.backButtonSelector != null ){
                $(self.options.backButtonSelector).on('click', function(){
                    self._goBack();
                });
            }

            /*if ( self.options.concern ) {
                $('li[data-choice='+self.options.concern+']').on('click', function () {
                    if ($(this).hasClass('selected')) {
                        $(this).removeClass('selected');
                    } else {
                        $(this).addClass('selected');
                    }
                });
            }*/

            $('#saveforlater-validate-detail').submit(function(){
                if( self.isValid() ){
                    var email = $('#saveforlater-validate-detail').find('input[type="email"]').val();
                    self.setCookie('hair_analysis_email', email, self.options.cookieExpiryTime);

                    if( $("#is_saveforlater").is(":checked") ){
                        window.dataLayer = window.dataLayer || [];
                        dataLayer.push({
                            'event': 'newsletterSignup',
                            'eventCategory' : 'Newsletter',
                            'eventAction': 'Submit',
                            'email':'muneeb@gmail.com',
                            'eventLabel': 'Skin Diagnostic'
                        });
                    }
                }
            });

            if( typeof $('#prepare_ids').val() === 'string' && $('#prepare_ids').val() != '' ){
                self.setCookie('hair_analysis_prepare', $('#prepare_ids').val(), self.options.cookieExpiryTime);
            }

            if( typeof $('#cleans_ids').val() === 'string' && $('#cleans_ids').val() != '' ){
                self.setCookie('hair_analysis_cleanse', $('#cleans_ids').val(), self.options.cookieExpiryTime);
            }

            if( typeof $('#treat_ids').val() === 'string' && $('#treat_ids').val() != '' ){
                self.setCookie('hair_analysis_treat', $('#treat_ids').val(), self.options.cookieExpiryTime);
            }

            if( typeof $('#recommended_product_ids').val() === 'string' && $('#recommended_product_ids').val() != '' ){
                self.setCookie('hair_analysis_alternate', $('#recommended_product_ids').val(), self.options.cookieExpiryTime);
            }

            if( typeof $('#top_products_ids').val() === 'string' && $('#top_products_ids').val() != '' ){
                self.setCookie('skin_analysis_top_products', $('#top_products_ids').val(), self.options.cookieExpiryTime);
            }

            if( typeof $('#lotions_ids').val() === 'string' && $('#lotions_ids').val() != '' ){
                self.setCookie('skin_analysis_lotions', $('#lotions_ids').val(), self.options.cookieExpiryTime);
            }

            if( typeof $('#cleansers_ids').val() === 'string' && $('#cleansers_ids').val() != '' ){
                self.setCookie('skin_analysis_cleansers', $('#cleansers_ids').val(), self.options.cookieExpiryTime);
            }

            //newsletter signup
            if( self.options.newsletterSignUpSelector != null){
                $(self.options.newsletterSignUpSelector).on('click', function(){
                    if( $(this).val() == 1){
                        self.setCookie('hair_analysis_newsletter_signup', '', self.options.cookieExpiryTime);
                        $(this).removeAttr('checked');
                        $(this).val('');
                    } else {
                        self.setCookie('hair_analysis_newsletter_signup', 1, self.options.cookieExpiryTime);
                        $(this).attr('checked', 'checked');
                        $(this).val(1);
                    }
                });
            }

            //saving data for guest on page load
            //this function must be triggered at the end
            if( self.options.onLoad == 1 && self.options.guestSaveUrl != null ){
                self._saveDataForGuest();
            }

            if ( self.options.addToFavoritesUrl != null ) {
                self.__addProductToFavorites();
            }

            if(
                self.options.addTopAllToBag != null &&
                self.options.addToCartUrl != null
            ) {
                if( $('input[name="top_products[]"]:checked').length == 0 ){
                    $(self.options.addTopAllToBag).attr('disabled', true);
                } else {
                    $(self.options.addTopAllToBag).removeAttr('disabled');
                    $(self.options.addTopAllToBag).on('click', function(){
                        self._addTopProductsToCart();
                    });
                }

                if( $('input[name="lotions_products[]"]:checked').length == 0 ){
                    $(self.options.addLotionAllToBag).attr('disabled', true);
                } else {
                    $(self.options.addLotionAllToBag).removeAttr('disabled');
                    $(self.options.addLotionAllToBag).on('click', function(){
                        self._addLotionProductsToCart();
                    });
                }

                if( $('input[name="cleansers_products[]"]:checked').length == 0 ){
                    $(self.options.addCleanserAllToBag).attr('disabled', true);
                } else {
                    $(self.options.addCleanserAllToBag).removeAttr('disabled');
                    $(self.options.addCleanserAllToBag).on('click', function(){
                        self._addCleanserProductsToCart();
                    });
                }
            }

            var topTotal = 0;
            $('input[name="top_products[]"]:checked').each(function(){
                var dataIterator = $(this).attr('data-iterator');
                var id = '#product_'+dataIterator;
                var price = $(id).find('span#max').text();
                if( !price ) {
                    price = $(id).find('span.price').text();
                }
                if( price ){
                    var result = price.match(/\d+/g);
                    var decimal = parseFloat( 0+'.'+result[1] ).toFixed(2);
                    var actualValue = parseFloat(result[0]) +  parseFloat(decimal);
                    topTotal += actualValue;
                }
            });


            setTimeout(function(){
                if(topTotal > 0){
                    $("#top_products_price").text('$'+topTotal.toFixed(2));
                    $("#top_products_price_mobile").text('$'+topTotal.toFixed(2));
                }
            }, 1000);

            $('.top-section').on('click', function(){
                var total = 0;
                var dataIterator = $(this).attr('data-iterator');
                var id = '#product_'+dataIterator;
                var price = $(id).find('span#max').text();
                if( !price ) {
                    price = $(id).find('span.price').text();
                }
                if( price ){
                    var result = price.match(/\d+/g);
                    var decimal = parseFloat( 0+'.'+result[1] ).toFixed(2);
                    var actualValue = parseFloat(result[0]) +  parseFloat(decimal);

                    var actualTopTotal = $("#top_products_price").text();
                    if( actualTopTotal ){
                        var result = actualTopTotal.match(/\d+/g);
                        var decimal = parseFloat( 0+'.'+result[1] ).toFixed(2);
                        var actualTopTotalValue = parseFloat(result[0]) +  parseFloat(decimal);
                        if( $(this).is(':checked') ){
                            actualTopTotal = actualTopTotalValue+actualValue;
                        } else {
                            actualTopTotal = actualTopTotalValue-actualValue;
                        }
                        $("#top_products_price").text('$'+actualTopTotal.toFixed(2));
                        $("#top_products_price").text('$'+actualTopTotal.toFixed(2));
                    }

                }
            });

            var lotionTotal = 0;
            $('input[name="lotions_products[]"]:checked').each(function(){
                var dataIterator = $(this).attr('data-iterator');
                var id = '#product_'+dataIterator;
                var price = $(id).find('span#max').text();
                if( !price ) {
                    price = $(id).find('span.price').text();
                }
                if( price ){
                    var result = price.match(/\d+/g);
                    var decimal = parseFloat( 0+'.'+result[1] ).toFixed(2);
                    var actualValue = parseFloat(result[0]) +  parseFloat(decimal);
                    lotionTotal += actualValue;
                }
            });

            setTimeout(function(){
                if(lotionTotal > 0){
                    $("#lotions_price").text('$'+lotionTotal.toFixed(2));
                    $("#lotions_price_mobile").text('$'+lotionTotal.toFixed(2));
                }
            }, 1000);

            $('.lotion-section').on('click', function(){
                var lotionTotal = 0;
                var dataIterator = $(this).attr('data-iterator');
                var id = '#product_'+dataIterator;
                var price = $(id).find('span#max').text();
                if( !price ) {
                    price = $(id).find('span.price').text();
                }
                if( price ){
                    var result = price.match(/\d+/g);
                    var decimal = parseFloat( 0+'.'+result[1] ).toFixed(2);
                    var actualValue = parseFloat(result[0]) +  parseFloat(decimal);

                    var actualLotionTotal = $("#lotions_price").text();
                    if( actualLotionTotal ){
                        var result = actualLotionTotal.match(/\d+/g);
                        var decimal = parseFloat( 0+'.'+result[1] ).toFixed(2);
                        var actualLotionTotalValue = parseFloat(result[0]) +  parseFloat(decimal);
                        if( $(this).is(':checked') ){
                            actualLotionTotal = actualLotionTotalValue+actualValue;
                        } else {
                            actualLotionTotal = actualLotionTotalValue-actualValue;
                        }
                        $("#lotions_price").text('$'+actualLotionTotal.toFixed(2));
                        $("#lotions_price_mobile").text('$'+actualLotionTotal.toFixed(2));
                    }

                }
            });

            var cleanserTotal = 0;
            $('input[name="cleansers_products[]"]:checked').each(function(){
                var dataIterator = $(this).attr('data-iterator');
                var id = '#product_'+dataIterator;
                var price = $(id).find('span#max').text();
                if( !price ) {
                    price = $(id).find('span.price').text();
                }
                if( price ){
                    var result = price.match(/\d+/g);
                    var decimal = parseFloat( 0+'.'+result[1] ).toFixed(2);
                    var actualValue = parseFloat(result[0]) +  parseFloat(decimal);
                    cleanserTotal += actualValue;
                }
            });


            setTimeout(function(){
                if(cleanserTotal > 0){
                    $("#cleansers_price").text('$'+cleanserTotal.toFixed(2));
                    $("#cleansers_price_mobile").text('$'+cleanserTotal.toFixed(2));
                }
            }, 1000);

            $('.cleanser-section').on('click', function(){
                var cleanserTotal = 0;
                var dataIterator = $(this).attr('data-iterator');
                var id = '#product_'+dataIterator;
                var price = $(id).find('span#max').text();
                if( !price ) {
                    price = $(id).find('span.price').text();
                }
                if( price ){
                    var result = price.match(/\d+/g);
                    var decimal = parseFloat( 0+'.'+result[1] ).toFixed(2);
                    var actualValue = parseFloat(result[0]) +  parseFloat(decimal);

                    var actualCleanserTotal = $("#cleansers_price").text();
                    if( actualCleanserTotal ){
                        var result = actualCleanserTotal.match(/\d+/g);
                        var decimal = parseFloat( 0+'.'+result[1] ).toFixed(2);
                        var actualCleanserTotalValue = parseFloat(result[0]) +  parseFloat(decimal);
                        if( $(this).is(':checked') ){
                            actualCleanserTotal = actualCleanserTotalValue+actualValue;
                        } else {
                            actualCleanserTotal = actualCleanserTotalValue-actualValue;
                        }
                        $("#cleansers_price").text('$'+actualCleanserTotal.toFixed(2));
                        $("#cleansers_price_mobile").text('$'+actualCleanserTotal.toFixed(2));
                    }

                }
            });
        },

        _addCleanserProductsToCart: function() {
            $(self.options.minicartSelector).trigger('contentLoading');
            var ids = '';
            $('input[name="cleansers_products[]"]:checked').each(function(index, element){
                ids += $(element).val()+',';
            });

            self = this;
            $(self.options.addCleanserAllToBag).attr('disabled', true);
            $(self.options.addCleanserAllToBag).text('Adding Products To Bag...');
            $.ajax({
                url: self.options.addToCartUrl,
                dataType: 'JSON',
                type: 'POST',
                data: { ids: ids },
                success: function(response){
                    $(self.options.minicartSelector).trigger('contentUpdated');
                    $(self.options.addCleanserAllToBag).text('Products Added To Bag');
                    if( response.success == true ){
                        $('[data-role="loader-minicart"]').show();
                        self.showMiniCart();
                        console.log(response.message);
                    } else if( response.error == true ){
                        console.log(response.message);
                    }
                },
                error: function(response){
                    console.log(response.message);
                }
            }).always(function(){
                setTimeout(function () {
                    $('[data-role="loader-minicart"]').hide();
                    $(self.options.addCleanserAllToBag).text('Add Products To Bag');
                    $(self.options.addCleanserAllToBag).removeAttr('disabled');
                },1000);
            });

            $(self.options.minicartSelector).on('contentUpdated', function(){
                $('[data-role="loader-minicart"]').hide();
            });
        },

        _addLotionProductsToCart: function() {
            $(self.options.minicartSelector).trigger('contentLoading');
            var ids = '';
            $('input[name="lotions_products[]"]:checked').each(function(index, element){
                ids += $(element).val()+',';
            });

            self = this;
            $(self.options.addLotionAllToBag).attr('disabled', true);
            $(self.options.addLotionAllToBag).text('Adding Products To Bag...');
            $.ajax({
                url: self.options.addToCartUrl,
                dataType: 'JSON',
                type: 'POST',
                data: { ids: ids },
                success: function(response){
                    $(self.options.minicartSelector).trigger('contentUpdated');
                    $(self.options.addLotionAllToBag).text('Products Added To Bag');
                    if( response.success == true ){
                        $('[data-role="loader-minicart"]').show();
                        self.showMiniCart();
                        console.log(response.message);
                    } else if( response.error == true ){
                        console.log(response.message);
                    }
                },
                error: function(response){
                    console.log(response.message);
                }
            }).always(function(){
                setTimeout(function () {
                    $('[data-role="loader-minicart"]').hide();
                    $(self.options.addLotionAllToBag).text('Add Products To Bag');
                    $(self.options.addLotionAllToBag).removeAttr('disabled');
                },1000);
            });

            $(self.options.minicartSelector).on('contentUpdated', function(){
                $('[data-role="loader-minicart"]').hide();
            });
        },

        _addTopProductsToCart: function() {
            $(self.options.minicartSelector).trigger('contentLoading');
            var ids = '';
            $('input[name="top_products[]"]:checked').each(function(index, element){
                ids += $(element).val()+',';
            });

            self = this;
            $(self.options.addTopAllToBag).attr('disabled', true);
            $(self.options.addTopAllToBag).text('Adding Products To Bag...');
            $.ajax({
                url: self.options.addToCartUrl,
                dataType: 'JSON',
                type: 'POST',
                data: { ids: ids },
                success: function(response){
                    $(self.options.minicartSelector).trigger('contentUpdated');
                    $(self.options.addTopAllToBag).text('Products Added To Bag');
                    if( response.success == true ){
                        $('[data-role="loader-minicart"]').show();
                        self.showMiniCart();
                        console.log(response.message);
                    } else if( response.error == true ){
                        console.log(response.message);
                    }
                },
                error: function(response){
                    console.log(response.message);
                }
            }).always(function(){
                setTimeout(function () {
                    $('[data-role="loader-minicart"]').hide();
                    $(self.options.addTopAllToBag).text('Add Products To Bag');
                    $(self.options.addTopAllToBag).removeAttr('disabled');
                },1000);
            });

            $(self.options.minicartSelector).on('contentUpdated', function(){
                $('[data-role="loader-minicart"]').hide();
            });
        },

        __addProductToFavorites: function(){
            $('#top-products-favorites').on('click', function () {
                var topProductIds = $('#top_products_ids').val();
                console.log(topProductIds);
                self.sendAddToFavoritesRequest(topProductIds);
            });

            $('#lotion-products-favorites').on('click', function () {
                var lotionProductIds = $('#lotions_ids').val();
                console.log(lotionProductIds);
                self.sendAddToFavoritesRequest(lotionProductIds);
            });

            $('#cleanser-products-favorites').on('click', function () {
                var cleanserProductIds = $('#cleansers_ids').val();
                console.log(cleanserProductIds);
                self.sendAddToFavoritesRequest(cleanserProductIds);
            });

        },

        sendAddToFavoritesRequest: function(ids) {
            $.ajax({
                url: self.options.addToFavoritesUrl,
                dataType: 'JSON',
                type: 'POST',
                data: { ids: ids },
                success: function(response){
                    console.log('succcess');
                },
                error: function(response){
                    console.log('error');
                }
            });
        },

        showMiniCart: function(){
            var self = this;
            $(".links-topcart").toggleClass('opened').siblings('.links-hover').removeClass('opened');
            $('[data-iconlink]').removeClass('active');
            if( $('.links-' + $(this).attr('data-iconlink')).hasClass('opened') ) {
                $('[data-iconlink="topcart"]').addClass('active');
            }
            self.options.minicartShowed = true;
        },

        /**
         * Method to save result for guest if onLoad
         * feature in enabled form the store > configuration
         *
         * @param void
         * @return void
         */
        _saveDataForGuest: function(){
            self = this;
            $.ajax({
                url: self.options.guestSaveUrl,
                dataType: 'JSON',
                type: 'GET',
                data: { answers: self.options.answers },
                success: function(response){
                    if( response.success == true ){
                        console.log(response.message);
                    } else if( response.error == true ){
                        console.log(response.message);
                    }
                },
                error: function(response){
                    console.log(response.message);
                },
                always: function(){}
            });
        },

        _goBack: function(){
            self = this;
            self.options.answers.pop();
        },

        _retakeHairAnalysis: function(){
            self = this;
            self.setCookie('hair_analysis','', 1);
            self.setCookie('hair_analysis_prepare', '', 1);
            self.setCookie('hair_analysis_cleanse', '', 1);
            self.setCookie('hair_analysis_treat', '', 1);
            self.setCookie('hair_analysis_alternate', '', 1);
            self.setCookie('hair_analysis_newsletter_signup', '', 1);
        },

        _retakeSkinAnalysis: function(){
            self = this;
            self.setCookie('skin_analysis','', 1);
            self.setCookie('skin_analysis_top_products', '', 1);
            self.setCookie('skin_analysis_lotions', '', 1);
            self.setCookie('skin_analysis_cleansers', '', 1);
        },

        _answersSelection: function(){
            self = this;
            var selector = [
                "a[data-choice="+self.options.stepInput1+"]",
                "a[data-choice="+self.options.stepInput2+"]",
                // "a[data-choice="+self.options.concern+"]",
                self.options.answerSelector+' > div'
            ].join(',');
            $(document).on('click', selector, function(e) {
                e.preventDefault();
                var dataChoice = '', id = '';
                if($(this).hasClass('basics-continue')) {
                    dataChoice = self.options.stepInput1;
                    id = '1';
                } else if ($(this).hasClass('info-continue')) {
                    dataChoice = self.options.stepInput2;
                    id = '1';
                } else {
                    dataChoice = $(this).parent('li').attr('data-choice');
                    id = $(this).parent('li').attr('id');
                }
                var ans = {};
                if(dataChoice === self.options.stepInput1) {
                    if (
                        !($(self.options.stepNameSelector).val().length
                            && $(self.options.stepEmailSelector).val().length
                            && $(self.options.stepCitySelector).val().length
                            && $(self.options.stepZipSelector).val().length
                        )
                    ){
                        $(self.options.errorMessage).show();
                        return false;
                    }
                    if (!self.validateEmail($(self.options.stepEmailSelector).val())) {
                        $(self.options.emailError).show();
                        return false;
                    }
                    $(self.options.errorMessage).hide();
                    ans[$(self.options.stepNameSelector).attr('name')] = $(self.options.stepNameSelector).val();
                    ans[$(self.options.stepEmailSelector).attr('name')] = $(self.options.stepEmailSelector).val();
                    ans[$(self.options.stepCitySelector).attr('name')] = $(self.options.stepCitySelector).val();
                    ans[$(self.options.stepZipSelector).attr('name')] = $(self.options.stepZipSelector).val();
                } else if (dataChoice === self.options.stepInput2){
                    ans[$(self.options.stepGenderSelector).attr('name')] = $(self.options.stepGenderSelector).find(":selected").val();
                    ans[$(self.options.stepAgeGroupSelector).attr('name')] = $(self.options.stepAgeGroupSelector).find(":selected").val();
                } else {
                    ans[dataChoice] = id;
                }
                self.options.answers.push(ans);
                console.log(self.options.answers);
                console.log($('.hastep-'+self.options.stepActive));
                console.log($(this).parent('li').attr('id'));
                console.log($(this).parent('li').attr('data-choice'));
                if (($(this).parent('li').attr('data-choice') == 'skin_concerns' && $(this).parent('li').attr('id') == 4)
                    // ||
                    // ($(this).parent('li').attr('data-choice') == 'skin_sensitivity' && $(this).parent('li').attr('id') == 1)
                ) {
                    self.options.stepCount = 3;
                } else {
                    self.options.stepCount = $('#hastep').val();
                }
                self.options.stepActive = (self.options.stepCount*1) + 1;
                console.log('step count--'+self.options.stepCount);
                console.log('step active--'+self.options.stepActive);
                $(this).parent('li').addClass('selected').siblings('li').removeClass('selected');

                if( self.options.stepActive > $('.hastep-bar li').length ) {
                    self._processAnswers();
                    return false;
                }

                setTimeout(function() {
                    $(self.options.selector).addClass('bgha-'+self.options.stepActive);
                    $('.hastep-title h4 span').text(self.options.stepActive);
                    $('.hastep-'+self.options.stepCount).removeClass('current').slideUp(100);
                    $('#skin-quiz-hastep-4').hide();
                    if ($('.hastep-'+self.options.stepCount).hasClass('hastep-3')){
                        if ($('#hastep-4-a').hasClass('hastep-4-a')) {
                            if (self.options.answers[2]['regimen_type'] == 1 && self.options.answers[3]['skin_concerns'] == 4) {
                                $('#hastep-4-a').removeClass('hastep-4-a').removeClass('current').slideUp(100);
                                $('#hastep-4-c').addClass('current hastep-4-c').slideDown();
                                $('.hastep-bar li').eq(self.options.stepCount).addClass('current').siblings('li').removeClass('current');
                                $('#hastep').val(self.options.stepActive);
                            }
                        } else {
                            if ($('#hastep-4-c').hasClass('hastep-4-c')) {
                                if (self.options.answers[2]['regimen_type'] == 1 && self.options.answers[3]['skin_concerns'] == 4 && self.options.answers[4]['skin_sensitivity'] == 1) {
                                    $('#hastep-4-c').removeClass('hastep-4-c').removeClass('current').slideUp(100);
                                    $('#hastep-4-d').addClass('current').slideDown();
                                    $('.hastep-bar li').eq(self.options.stepCount).addClass('current').siblings('li').removeClass('current');
                                    $('#hastep').val(self.options.stepActive);
                                }
                            } else {
                                if(self.options.answers[2]['regimen_type'] == 1) {
                                    $('#hastep-4-a').addClass('current hastep-4-a').slideDown();
                                    $('#skin-quiz-hastep-4').show();
                                    $('.hastep-bar li').eq(self.options.stepCount).addClass('current').siblings('li').removeClass('current');
                                    $('#hastep').val(self.options.stepActive);
                                } else if (self.options.answers[2]['regimen_type'] == 2) {
                                    $('#hastep-4-b').addClass('current').slideDown();
                                    $('#skin-quiz-hastep-4').show();
                                    $('.hastep-bar li').eq(self.options.stepCount).addClass('current').siblings('li').removeClass('current');
                                    $('#hastep').val(self.options.stepActive);
                                }
                            }
                        }
                    } else if ($('.hastep-'+self.options.stepActive).hasClass('hastep-5')) {
                        if(self.options.answers[2]['regimen_type'] == 1) {
                            $('#hastep-5-a').addClass('current').slideDown();
                        } else if (self.options.answers[2]['regimen_type'] == 2) {
                            $('#hastep-5-b').addClass('current').slideDown();
                        }
                        $('.hastep-bar li').eq(self.options.stepCount).addClass('current').siblings('li').removeClass('current');
                        $('#hastep').val(self.options.stepActive);
                    } else if ($('.hastep-'+self.options.stepActive).hasClass('hastep-6')) {
                        if(self.options.answers[2]['regimen_type'] == 2) {
                            $('#hastep-5-b').addClass('current').slideDown();
                            self._processAnswers();
                            return false;
                        } else {
                            $('.hastep-'+self.options.stepActive).addClass('current').slideDown();
                            $('.hastep-bar li').eq(self.options.stepCount).addClass('current').siblings('li').removeClass('current');
                            $('#hastep').val(self.options.stepActive);
                        }
                        $('.hastep-bar li').eq(self.options.stepCount).addClass('current').siblings('li').removeClass('current');
                        $('#hastep').val(self.options.stepActive);
                    } else {
                        $('.hastep-'+self.options.stepActive).addClass('current').slideDown();
                        $('.hastep-bar li').eq(self.options.stepCount).addClass('current').siblings('li').removeClass('current');
                        $('#hastep').val(self.options.stepActive);
                    }

                    if(self.options.stepActive > 1) {
                        $('.action.back').fadeIn();
                    } else if(self.options.stepActive == 0) {
                        return false;
                    } else {
                        $('.action.back').fadeOut();
                    }
                },250);
            });
        },

        validateEmail: function($email) {
            var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
            return emailReg.test( $email );
        },

        _processAnswers: function() {
            self = this;
            $.ajax({
                url: self.options.requestUrl,
                dataType: 'JSON',
                type: 'POST',
                data: { answers: self.options.answers },
                success: function(response){
                    if( response.success == true ){
                        console.log(response.message);
                        self.setCookie('skin_analysis',response.hair_analysis, self.options.cookieExpiryTime);
                        window.location.href = self.options.resultPage;
                    } else if( response.error == true ){
                        console.log(response.message);
                    }
                },
                error: function(response){
                    console.log(response.message);
                },
                always: function(){}
            });
        },

        /**
         * Set cookie for one month for
         * newsletter popup
         *
         * @param {String} cookieName
         * @param {Number | String} cookieValue
         * @param {Number} exdays (no of expiry days)
         */
        setCookie: function(cookieName, cookieValue, minutes){
            var d = new Date();
            d.setTime(d.getTime() + (minutes*60*1000));
            var expires = "expires="+ d.toUTCString();
            document.cookie = cookieName + "=" + cookieValue + ";" + expires + ";path=/";
        },

        /**
         * Get cookie by cookie name
         *
         * @param {String} cookieName
         */
        getCookie: function(cookieName){
            var name = cookieName + "=";
            var decodedCookie = decodeURIComponent(document.cookie);
            var ca = decodedCookie.split(';');
            for(var i = 0; i <ca.length; i++) {
                var c = ca[i];
                while (c.charAt(0) == ' ') {
                    c = c.substring(1);
                }
                if (c.indexOf(name) == 0) {
                    return c.substring(name.length, c.length);
                }
            }
            return "";
        },

        _hairAnlysisSteps: function() {
            self = this;
            $(document).on('click', self.options.selector+' .action.started', function(e) {
                e.preventDefault();
                $('.haintro').slideUp().next('.hasteps').slideDown().find('.hastep-1').slideDown().addClass('current');
                $('#hastep').val('1');
                $('body,html').animate({ scrollTop: 0 }, 300);
                $(self.options.selector).addClass('bgha-1');
            });

            $(document).on('click', self.options.selector+' .action.back', function(e) {
                e.preventDefault();

                self.options.stepCount = $('#hastep').val();
                self.options.stepActive = (self.options.stepCount*1) - 1;

                $(self.options.selector).removeClass('bgha-'+self.options.stepCount);
                $('.hastep-title h4 span').text(self.options.stepActive);
                $('.hastep-'+self.options.stepCount).removeClass('current').slideUp(100).find('li').removeClass('selected');
                $('.hastep-'+self.options.stepActive).addClass('current').slideDown();
                $('.hastep-bar li').eq(self.options.stepCount-2).addClass('current').siblings('li').removeClass('current');
                $('#hastep').val(self.options.stepActive);
                if(self.options.stepActive > 1) {
                    $('.action.back').fadeIn();
                } else {
                    $('.action.back').fadeOut();
                }
            });
        },

        /**
         * Check if form pass validation rules without submit
         * @return boolean
         */
        isValid: function () {
            return $('#saveforlater-validate-detail').valid();
        }
    });
});
