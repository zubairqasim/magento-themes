define([
    'jquery',
    'Amasty_Label/js/configurable/reload'
], function ($, reloader) {
    'use strict';

    return function (widget) {
        $.widget('mage.configurable', widget, {
            _changeProductImage: function () {
                var productId = this.simpleProduct,
                    imageContainer = null,
                    originalProductId = this.options.spConfig['original_product_id'];

                if (this.inProductList) {
                    imageContainer = this.element.closest('li.item').find(this.options.spConfig['label_category']);
                } else {
                    imageContainer = this.element.closest('.column.main').find(this.options.spConfig['label_product']);
                }

                imageContainer.find('.amasty-label-container').hide();

                if (!productId) {
                    productId = this.options.spConfig['original_product_id'];
                }

                if (typeof this.options.spConfig['label_reload'] != 'undefined') {
                    reloader.reload(
                        imageContainer,
                        productId,
                        this.options.spConfig['label_reload'],
                        this.inProductList ? 1 : 0,
                        originalProductId
                    );
                }

                return this._super();
            },

            /**
             * Populates an option's selectable choices.
             * @private
             * @param {*} element - Element associated with a configurable option.
             */
            _fillSelect: function (element) {
                var attributeId = element.id.replace(/[a-z]*/, ''),
                    options = this._getAttributeOptions(attributeId),
                    prevConfig,
                    index = 1,
                    allowedProducts,
                    i,
                    j,
                    finalPrice = parseFloat(this.options.spConfig.prices.finalPrice.amount),
                    optionFinalPrice,
                    optionPriceDiff,
                    optionPrices = this.options.spConfig.optionPrices,
                    allowedProductMinPrice;

                this._clearSelect(element);
                element.options[0] = new Option('', '');
                element.options[0].innerHTML = this.options.spConfig.chooseText;
                prevConfig = false;

                if (element.prevSetting) {
                    prevConfig = element.prevSetting.options[element.prevSetting.selectedIndex];
                }

                if (options) {
                    for (i = 0; i < options.length; i++) {
                        allowedProducts = [];
                        optionPriceDiff = 0;

                        /* eslint-disable max-depth */
                        if (prevConfig) {
                            for (j = 0; j < options[i].products.length; j++) {
                                // prevConfig.config can be undefined
                                if (prevConfig.config &&
                                    prevConfig.config.allowedProducts &&
                                    prevConfig.config.allowedProducts.indexOf(options[i].products[j]) > -1) {
                                    allowedProducts.push(options[i].products[j]);
                                }
                            }
                        } else {
                            allowedProducts = options[i].products.slice(0);

                            if (typeof allowedProducts[0] !== 'undefined' &&
                                typeof optionPrices[allowedProducts[0]] !== 'undefined') {
                                allowedProductMinPrice = this._getAllowedProductWithMinPrice(allowedProducts);
                                optionFinalPrice = parseFloat(optionPrices[allowedProductMinPrice].finalPrice.amount);
                                optionPriceDiff = optionFinalPrice - finalPrice;

                                if (optionPriceDiff !== 0) {
                                    // options[i].label = options[i].label + ' ' + priceUtils.formatPrice(
                                    //     optionPriceDiff,
                                    //     this.options.priceFormat,
                                    //     true);

                                    options[i].label = options[i].label;
                                }
                            }
                        }

                        if (allowedProducts.length > 0) {
                            options[i].allowedProducts = allowedProducts;
                            element.options[index] = new Option(this._getOptionLabel(options[i]), options[i].id);

                            if (typeof options[i].price !== 'undefined') {
                                element.options[index].setAttribute('price', options[i].price);
                            }

                            element.options[index].config = options[i];
                            index++;
                        }

                        /* eslint-enable max-depth */
                    }
                }
            },

            /**
             * Callback which fired after gallery gets initialized.
             *
             * @param {HTMLElement} element - DOM element associated with gallery.
             */
            _onGalleryLoaded: function (element) {
                var galleryObject = element.data('gallery');

                this.options.mediaGalleryInitial = galleryObject.returnCurrentImages();

                /*
                starts,
                custom work,
                reason: on page load show selected first option
                */
                if($('#product-options-wrapper').find('.super-attribute-select').length > 0) {

                    $("select[id^=attribute] option[value='']").remove(); //remove empty option

                    /*
                    first make sure, no hash value is found in URL
                    */
                    var attributeOptionVal = [];
                    $("select[id^=attribute] option").each(function() {
                        attributeOptionVal.push($(this).val());
                    });

                    var hashCheck = true;
                    var hashParam = window.location.hash.substr(1);
                    var splitHashParam = '';
                    var optionUrlVal = '';

                    if(hashParam) {
                        splitHashParam = hashParam.split('=');
                        if(splitHashParam[1] != undefined) {
                            optionUrlVal = splitHashParam[1];
                        }
                    }

                    if(optionUrlVal && $.inArray(optionUrlVal, attributeOptionVal) > -1) {
                        hashCheck = false;
                    }
                    /*
                    ends hash logic
                    */

                    if(hashCheck == true) { //if hashCheck value TRUE means no hash in URL
                        $("select[id^=attribute]").prop("selectedIndex", 0);
                        $("select[id^=attribute]").trigger("change");
                    }
                }
                /*
                ends
                */
            }
        });

        return $.mage.configurable;
    }
});
