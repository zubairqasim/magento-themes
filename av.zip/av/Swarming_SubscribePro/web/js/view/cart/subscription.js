define(
    [
        'ko',
        'jquery',
        'mage/translate',
        'uiComponent',
        'uiLayout',
        'Magento_Ui/js/model/messages',
        'Swarming_SubscribePro/js/model/product/price'
    ],
    function (ko, $, $t, Component, layout, Messages, productPriceModel) {
        'use strict';

        return Component.extend({
            defaults: {
                template: 'Swarming_SubscribePro/cart/subscription',
                oneTimePurchaseOption: '',
                subscriptionPriceTemplate: 'Swarming_SubscribePro/product/price/default/subscription',
                subscriptionOption: '',
                subscriptionOnlyMode: '',
                subscriptionAndOneTimePurchaseMode: '',
                qtyFieldSelector: '',
                quoteItemId: 0,
                product: {},
                isProductLoaded: false,
                subscriptionOptionValue: '',
                checkboxSubscriptionOptionValue: '',
                intervalValue: '',
                selectSubscriptionOption: ko.observableArray([]),
                selectIntervalOption: [],
                selectSubscriptionOptionValue: '',
                productPrice: {},
                priceConfig: {},
				subscriptionIntervalValue: '.subscription-title'
            },

            initialize: function () {
                this._super();
                this.initMessageComponent();
                this.isProductLoaded(true);
                this.listenDocumentClick(); //custom work, dynamic select options
            },

            initObservable: function () {
                this._super()
                    .observe([
                        'subscriptionOptionValue',
                        'isProductLoaded',
                        'intervalValue',
                        'checkboxSubscriptionOptionValue',
                        'selectSubscriptionOptionValue'
                    ])
                    .initProduct();

                $(this.qtyFieldSelector).on('change', this.onQtyFieldChanged.bind(this));

                this.subscriptionOptionValue.subscribe(this.onQtyFieldChanged.bind(this));

                return this;
            },

            listenDocumentClick: function () { //custom work, dynamic select options
                var self = this;
                $('.super-attribute-select').on('change', function (e) {

                    var discountMessage = self.productPrice.priceWithDiscountText();
                    self.populateSubscriptionDropdown(discountMessage);

                });
            },

            updateQtyCart: function () {
                $("#update_shopping_cart").trigger("click");
            },

            updateSubscriptionCartReload: function () {
                this.subscriptionOptionValue(this.selectSubscriptionOptionValue());
				if(this.selectSubscriptionOptionValue() === 'subscription'){
					$('.cart-Subscription-d2').show();
					$(this.subscriptionIntervalValue+'[data-id="'+this.quoteItemId+'"]').attr('data-value', 'Every ' + this.intervalValue());
				}
				this.updateQtyCart();
            },

            updateIntervalCartReload: function () {
				let _intervalValue = 'One Time';
				if(this.subscriptionOptionValue() !== 'onetime_purchase') {
					_intervalValue = 'Every ' + this.intervalValue();
					$('.cart-Subscription-d1').show();
				}
				$(this.subscriptionIntervalValue+'[data-id="'+this.quoteItemId+'"]').attr('data-value', _intervalValue);
                if(this.product.default_interval != undefined) {
                    if(this.intervalValue() != this.product.default_interval) {
                        console.log(this.intervalValue()+'====='+this.product.default_interval);
						if(this.intervalValue() == 'One Time') {
                            this.subscriptionOptionValue(this.oneTimePurchaseOption);
                        }
                        this.updateQtyCart();
                    }
                }

            },

            initProduct: function () {
                //load price from model
                this.productPrice = productPriceModel.create(this.product, this.priceConfig);

                var intervalOptions = [];
                intervalOptions = this.product.intervals;
                console.log(intervalOptions);
                //only for checkout cart page
                if(window.location.href.indexOf("checkout") > -1 && window.location.href.indexOf("cart") > -1) {
                    //intervalOptions.push('One Time');
                    this.selectSubscriptionOption = [
                                                        { Name: 'One Time', Value: this.oneTimePurchaseOption},
                                                        { Name: 'Monthly', Value: this.subscriptionOption}
                                                    ];
                }
                else {
                    this.populateSubscriptionDropdown(this.productPrice.priceWithDiscountText()); //custom work, dynamic select options
                }

                this.selectIntervalOption = intervalOptions;

                if(this.product.default_subscription_option == this.subscriptionOption) {
                    this.checkboxSubscriptionOptionValue(true); //custom checkbox set flag
                }

                if (this.isSubscriptionMode(this.subscriptionOnlyMode)) {
                    this.subscriptionOptionValue(this.subscriptionOption);
                    this.selectSubscriptionOptionValue(this.subscriptionOption); //custom select value work
                } else {
                    this.subscriptionOptionValue(this.product.default_subscription_option);
                    this.selectSubscriptionOptionValue(this.product.default_subscription_option); //custom select value work
                }
				
				/*if($('body').hasClass('catalog-product-view')) {
					this.subscriptionOptionValue(this.subscriptionOption);
                    this.selectSubscriptionOptionValue(this.subscriptionOption); //custom select value work
				}*/

                this.intervalValue(this.product.default_interval);

                if (this.isSubscriptionOption(this.subscriptionOption) || this.isSubscriptionMode(this.subscriptionOnlyMode)) {
                    this.validateQty();
                }
				
            },
			
            populateSubscriptionDropdown: function (discountMessage) { //custom work, dynamic select options
                /*this.selectSubscriptionOption = [
                                                    {
                                                        Name: 'Frequency: One Time Delivery',
                                                        Value: this.oneTimePurchaseOption
                                                    },
                                                    {
                                                        Name: 'Frequency: Regular Delivery ('+discountMessage+')',
                                                        Value: this.subscriptionOption
                                                    }
                                                ];*/
                this.selectSubscriptionOption([]);
                this.selectSubscriptionOption.push({
                                                        Name: 'One Time',
                                                        Value: this.oneTimePurchaseOption
                                                    },
													{
                                                        Name: 'Monthly',
                                                        Value: this.subscriptionOption
                                                    }
                                                );
            },

            manageVisibility: function () {
                if(this.product.default_subscription_option == this.subscriptionOption) {
                    return false;
                }
                return true;
            },

            manageIntervalVisibility: function () {
                if(this.product.default_subscription_option == this.oneTimePurchaseOption) {
                    return false;
                }

                return true;
            },

            initMessageComponent: function () {
                this.messageContainer = new Messages();
                this.createMessagesComponent();

                return this;
            },

            createMessagesComponent: function () {
                var messagesComponent = {
                    parent: this.name,
                    name: this.name + '.messages',
                    config: {messageContainer: this.messageContainer}
                };

                layout([$.extend(true, this.messages, messagesComponent)]);

                return this;
            },

            isSubscriptionMode: function(optionMode) {
                return this.product.subscription_option_mode == optionMode;
            },

            isSubscriptionOption: function(optionValue) {
                return this.product.default_subscription_option == optionValue;
            },

            onQtyFieldChanged: function () {
                if (this.subscriptionOptionValue() == this.oneTimePurchaseOption) {
                    return;
                }
                this.validateQty(true);
            },

            validateQty: function (showMessages) {
                var qtyField = $(this.qtyFieldSelector);
                var qty = qtyField.val();
                var errorMessage;

                var productMinQty = this.product.min_qty;
                if (productMinQty && qty < productMinQty) {
                    qtyField.val(productMinQty).trigger('change');
                    errorMessage = $t('Product requires minimum quantity of %qty for subscription.').replace('%qty', productMinQty);
                }

                var productMaxQty  = this.product.max_qty;
                if (productMaxQty && qty > productMaxQty) {
                    qtyField.val(productMaxQty).trigger('change');
                    errorMessage = $t('Product requires maximum quantity of %qty for subscription.').replace('%qty', productMaxQty);
                }

                if (showMessages && errorMessage) {
                    this.messageContainer.addErrorMessage({message: errorMessage});
                }
            },

            setVisibility: function () {
                this.toggleSubscriptionOptions();
            },
			
			intervalSubscriptionOption: function() {
				$(this.subscriptionIntervalValue).attr('data-value', 'Every ' + this.intervalValue());
			},

            toggleSubscriptionOptions: function () {
                var self = this;
                if (this.subscriptionOptionValue() == this.oneTimePurchaseOption) {
                    $("select[name='subscription_interval_checkbox']").hide();
                    var discountMessage = self.productPrice.priceWithDiscountText();
                    $(".first-m").show();
                    $(".second-m").hide();
                    $(".first-m").html(discountMessage);
                    /*$(".once").html(discountMessage+"<ul><li>Cancel or modify anytime</li><li>Free shipping</li></ul>"); */
                    //console.log(discountMessage+"Salik");
					$(this.subscriptionIntervalValue).attr('data-value', 'One Time');
                }
                else if(this.subscriptionOptionValue() == this.subscriptionOption) {
                    $("select[name='subscription_interval_checkbox']").show();
                    $(".first-m").hide();
                    $(".second-m").show();
                    $(".second-m").html("Save 15% &amp; Free Shipping &nbsp;<ul><li>Cancel or modify anytime</li><li>Never run out</li></ul>");
					
					$('[name="subscription_interval_checkbox"]').trigger('change');
                }
				
				
            },

            radioSubscriptionOption: function () {
                this.subscriptionOptionValue(this.selectSubscriptionOptionValue());
                this.toggleSubscriptionOptions();
            },

            subscriptionToggle: function(data, event) {
                var self = this,
					typeEvent = event.type,
					targetObj;

				if(typeEvent !== 'click') {
					targetObj = event.changedTouches[0].target;
				} else {
					targetObj = event.target;
				}

                if(!$(targetObj).hasClass('opened')) {
                    $(targetObj).addClass('opened').next('.subscription-content').show();
                    if (this.subscriptionOptionValue() == this.oneTimePurchaseOption) {
                        $(".first1").show();
                        $(".second1").hide();
                    }else if(this.subscriptionOptionValue() == this.subscriptionOption) {
                        $(".second1").show();
                        $(".first1").hide();
                    }
                } else {
                    $(targetObj).removeClass('opened').next('.subscription-content').hide();
                }

                $("body").on('click', function (e) {
                    if (!$(e.target).closest('.subscription-container').length) {
                        if (window.isBody != true) {
                            $('.subscription-title').removeClass('opened').next('.subscription-content').hide();
                        }
                    }
                });
            }
        });
    }
);
