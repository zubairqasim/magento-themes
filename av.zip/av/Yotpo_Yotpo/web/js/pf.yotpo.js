/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
/*jshint browser:true, jquery:true*/
/*global confirm:true*/
define([
    'jquery'
], function($){
    "use strict";
    $.widget('pf.yotpo', {

        options: {
            reviewElement   : null,
            writeElement    : null
        },
        
        _create: function () {
            var self = this;
            this._super();
        },
        
        _init: function () {
            if( this.options.reviewElement != null ){
                $(document).on("click", this.options.reviewElement, this.readReviews.bind(this));
            }

            if( this.options.writeElement != null ){
                $(document).on("click", this.options.writeElement, this.showReviewForm.bind(this));   
            }
            
            this._super();
        },

        readReviews: function(){
            if( $(".reviews").length > 0){
                $('html, body').animate({
                    scrollTop: $(".reviews").offset().top
                }, "fast");    
            }
        },

        showReviewForm: function(){
            if( $("#yotpo-main-widget-btn").length && $(".yotpo-widget-instance").length ){
				$("#yotpo-main-widget-btn").trigger('click')
                /*$(".write-review-wrapper").addClass("visible");     
                $(".write-review-wrapper").show();
                $('html, body').animate({
                    scrollTop: $(".yotpo-main-widget").offset().top
                }, "fast");*/
            }
        }
    });
    
    return $.pf.yotpo;
});
