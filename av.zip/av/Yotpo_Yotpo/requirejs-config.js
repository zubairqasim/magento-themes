var config = {
	map: {
       "*" : {
            "pf_yotpo" : "Yotpo_Yotpo/js/pf.yotpo",
        }
    }
};
