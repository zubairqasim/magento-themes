define([
    "jquery",
	"matchMedia",
	"jquery/ui",
    "domReady!",
], function($, mediaCheck) {
    "use strict";
	
	var self = this;

    $.widget('pf.bannerslider', {
		
		options: {
			selector: null,
			imageSrc: 'src',
			imageDesktop: 'data-des',
            imageMobile: 'data-mob',
			breadcrumbs: '.breadcrumbs'
        },
		
        _create: function () {
            self = this;
			
        },

        _init: function () {
			self = this;
			
			if (self.options.selector != null) {
				self._bannerSliderInit();
			}
		},
		
		_bannerSliderInit: function() {
			self = this;
			
			if($('html').hasClass('touch')) {
				$(self.options.selector + ' .bannerslide').addClass('is-stretch-mob');
			}
			
			mediaCheck({
				media: '(max-width: 767px)',
				entry: $.proxy(function () {
					self._bannerSliderMobile();
				}, this),
				exit: $.proxy(function () {
					self._bannerSliderDesktop();
				}, this)
			});
		},
		
		_bannerSliderDesktop: function () {
			self = this;
			//console.log('- des');
			//$(self.options.selector + ' .bannerslide').removeClass('is-stretch-mob');
			$(self.options.selector + ' .bannerslide').each(function(i) {
				if(!$(this).find('.image').hasClass('po-lazyimage') || $(this).find('.image').hasClass('loaded')) {
					//console.log('- ' + i + ' -- ' + $(this).find('img').attr(self.options.imageDesktop));
					$(this).find('.image img').attr(self.options.imageSrc, $(this).find('.image img').attr(self.options.imageDesktop));
				}
			});
		},
		
		_bannerSliderMobile: function () {
			self = this;
			//console.log('- mob');
			//$(self.options.selector + ' .bannerslide').addClass('is-stretch-mob');
			$(self.options.selector + ' .bannerslide').each(function(i) {
				if(!$(this).find('.image').hasClass('po-lazyimage') || $(this).find('.image').hasClass('loaded')) {
					//console.log('- ' + i + ' -- ' + $(this).find('img').attr(self.options.imageMobile));
					$(this).find('.image img').attr(self.options.imageSrc, $(this).find('.image img').attr(self.options.imageMobile));
				}
			});
		}
		
	});
 
    return $.pf.bannerslider;
});