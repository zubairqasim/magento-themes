define([
    'jquery',
	'jquery/ui'
], function($){
    "use strict";
    var self = this;
    $.widget('pf.helper', {
        _create: function () {
            self = this;
            this._super();
        },

        _init: function () {
            self = this;
            this._super();
        },

        /**
         *
         * @param cookieName
         * @param cookieValue
         * @param expiryTime
         * @param mode
         */
        setCookie: function(cookieName = 'cookieName', cookieValue = 'cookieValue', expiryTime = 1, mode = 'days'){
            var d = new Date();
            if(mode === 'hours') {
                d.setTime(d.getTime() + (expiryTime*60*60*1000));
            } else if(mode === 'minutes') {
                d.setTime(d.getTime() + (expiryTime*60*1000));
            } else if(mode === 'seconds') {
                d.setTime(d.getTime() + (expiryTime*1000));
            } else {
                d.setTime(d.getTime() + (expiryTime*24*60*60*1000));
            }
            var expires = "expires="+ d.toUTCString();
            document.cookie = cookieName + "=" + cookieValue + ";" + expires + ";path=/";
        },

        /**
         *
         * @param cookieName
         * @returns {string|boolean}
         */
        getCookie: function(cookieName){
            var name = cookieName + "=";
            var decodedCookie = decodeURIComponent(document.cookie);
            var ca = decodedCookie.split(';');
            for(var i = 0; i <ca.length; i++) {
                var c = ca[i];
                while (c.charAt(0) == ' ') {
                    c = c.substring(1);
                }
                if (c.indexOf(name) == 0) {
                    return c.substring(name.length, c.length);
                }
            }
            return false;
        },

    });

    return $.pf.helper;
});
