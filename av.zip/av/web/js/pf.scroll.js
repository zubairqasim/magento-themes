define([
    "jquery",
	"matchMedia",
    "jquery/ui",
], function($, mediaCheck) {
    "use strict";

	var globalPath	= location.href.split( '/' ), // Global Path by Location
		urlPath		= location.pathname, // Location Path Name
		urlPath_cms	= urlPath.split('/'), // Split Location Path Name by '/'
		protocol	= globalPath[0], // 'http/https' Protocol
		host		= globalPath[2], // 'host/domain' Name
		baseUrl		= protocol + '//' + host, // Base Url 
		hash		= location.hash, // Hash Params
		winWidth	= jQuery(window).width(), // Window Width
		screenWidth	= window.screen.width, // Screen Width
		
		html		= "html", // HTML
		body		= "body", // BODY
		main		= ".page-main", // MAIN DIV
		h			= ".header", // HEADER
		hc			= ".page-header", // HEADER CONTAINER
		hph			= ".header-placeholder", // HEADER PLACEHOLDER
		hsb			= ".header-ship-bar", // Ship Bar
		pl			= ".page-lead", // Page Lead
		sb			= ".sidebar", // SideBar
		mm			= ".mobile-menu",
		mMenu 		= ".ms-megamenu",
		cs			= ".category-specific",
		tb			= ".tabs-bar",
		lv			= ".block-layered-nav",
		selectDd	= "select", // Select DropDown
		isSlider	= ".swiper-container", // Slider Swiper Container
		cTopImg		= ".top-container .category-image",
		cTopImgWrap = ".top-container .category-detail-wrap",
		topBan		= ".topbanner-container",
		topBanImg	= ".topbanner-container .image",
		topBanContent = ".topbanner-container .content",

		setTimer	= null,	// SetTimeout Timer
		pointerEvent = 'click', // Default Click EVent		
		isMobile	= '#mobile_check', // Mobile Check Selector
		isMobileCheck = false, // Mobile Check Bolean
		pScroll		= 0, // Page Sroll 0
		resizeCounter,	// 0 - Mobile / 1 - Desktop
		isScreen, isResponsive, cmsPage, scrollTop, fixit;
	
    //Creating PF Scrolling Widget
    $.widget('pf.scrolling', {
		
		options: {
            selector: null,
			config: {},
        },
		
        _create: function () {
            var self = this;
			$(hc).before('<div class="header-placeholder">&nbsp;</div>');
			
			//this._super();
        },

        _init: function () {
			if( $('.tabs-bar').length > 0 && !$(body).hasClass('aw-store-locator-index-details') ) {
				this.pageScroll = this._doTabsBarSticky;
			} else if( $(body).hasClass('catalog-product-view') ) {
				this.pageScroll = this._doPdpSticky;
			} else {
				this.pageScroll = this._doHeaderSticky;
			}
			
			$(window).bind('scroll', this.pageScroll );
			$(window).trigger('scroll');
			//this._super();
		},
		
		_doHeaderSticky: function() {
			pScroll = $(this).scrollTop();
			scrollTop = $(main).offset().top;
			
			if( $(pl).length > 0 ) {
				scrollTop = $(pl).offset().top;
			}
			
			if( pScroll > scrollTop ) {
				//console.log('if');
				$(hc).addClass('page-header-sticky');
				$(hph).css({'display': 'block', 'height': scrollTop});
				setTimer = setTimeout(function() {
					$(hc).addClass('ready');
				},100);
			} else {
				//console.log('else');
				$(hc).removeClass('page-header-sticky ready');
				$(hph).attr('style','');
				if (setTimer) {
					clearTimeout(setTimer);
					setTimer = null;
				}
			}
		},
		
		_doPdpSticky: function() {
			pScroll = $(this).scrollTop();
			scrollTop = $(main).offset().top;
			
			var	stickyProduct = '.sticky-product',
				scrollWrapper = '.product-info-top',
				scrollContent = '.product-info-main',
				scrollDiameter, scrollLimit, headerHeight;
						
			if( $(pl).length > 0 ) {
				scrollTop = $(pl).offset().top;
			}
			
			if( pScroll > scrollTop ) {
				//console.log('if');
				headerHeight = $(stickyProduct).length ? $(stickyProduct).height() : $(hc).height();
				scrollDiameter = $(scrollWrapper).offset().top + $(scrollWrapper).height(),
				scrollLimit = scrollDiameter - $(scrollContent).outerHeight() - headerHeight;
				
				if( pScroll >= scrollLimit ) {
					$(scrollContent).css({ 'position': 'absolute', 'top': 'auto', 'bottom': 0 });
				} else {
					$(scrollContent).css({ 'position': 'fixed', 'top': headerHeight, 'bottom': 'auto' });
				}
			} else {
				//console.log('else');
				$(scrollContent).attr('style','');
			}
			$(scrollWrapper).css({'min-height': $(scrollContent).outerHeight()});
		},
		
		_doTabsBarSticky: function() {
			pScroll = $(this).scrollTop();
			scrollTop = $(main).offset().top - $('.tabs-bar').height();
			
			if( pScroll > scrollTop ) {
				//console.log('if');
				$('.tabs-bar').addClass('tabs-bar-sticky');
				$(pl).css({ 'padding-bottom': $('.tabs-bar').height() });
			} else {
				//console.log('else');
				$('.tabs-bar').removeClass('tabs-bar-sticky');
				$(pl).attr('style','');
			}
		}
		
	});
 
    //return $.pf.scrolling;
    $.pf.scrolling();
});