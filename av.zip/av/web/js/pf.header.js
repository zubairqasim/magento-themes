define([
    "jquery",
	"matchMedia",
    "jquery/ui",
	"domReady!",
], function($, mediaCheck) {
    "use strict";
    window.isBody = false;
 
    //creating jquery widget
    $.widget('pf.header', {
		options: {
            responsive: false
        },
		
        _create: function () {
            var self = this;
			this._super();
			
			this.gHeaderBar = '.global-bar-header';
			this.gHeaderBarClose = '.global-bar-header .close';
			this._headerGlobalBar(this.gHeaderBar, this.gHeaderBarClose);
			
			if( $('[data-iconlink]').length > 0 ) {
				this._headerLinksToggle();
			}
			
			//this._navSwitch();
        },

        _init: function () {
            this._super();
			
		},
		
		_headerGlobalBar: function(gbar,gbarClose) {
			//$(gbar).append('<a href="#" class="close">close</a>');
			$(document).on('click', gbarClose, function(e){
				e.preventDefault();
				$(gbar).slideUp( 300, function() { $(gbar).remove(); });
			});
			
			$(gbarClose).remove();
			
			let promoRotate = setInterval(function(){
				let promoCont = $(gbar).find('#shippingLabel'),
					promoMessages = $(promoCont).find('div'),
					promoMessage = promoMessages.eq(0);
				
				if(promoMessages.length > 1) {
					promoMessage.animate({height: 0, opacity: 0 },{duration: 200, queue: false, complete: function() { promoMessage.appendTo(promoCont); promoMessage.attr('style','') }});
				} else {
					clearInterval(promoRotate);
				}
			}, 8000);
		},
		
		_headerLinksToggle: function() {
			$(".header .links [data-iconlink]").on('click', function(e) {
				e.preventDefault();
				$('.links-' + $(this).attr('data-iconlink')).toggleClass('opened').siblings('.links-hover').removeClass('opened');
				$('[data-iconlink]').removeClass('active');
				if( $('.links-' + $(this).attr('data-iconlink')).hasClass('opened') ) {
					$('[data-iconlink="'+$(this).attr('data-iconlink')+'"]').addClass('active');
				}
				if( ($(this).attr('data-iconlink').indexOf('search') != -1) && ($(this).hasClass('active')) )  {
                    setTimeout(function() {
                        $('#search').focus();
                    },100);
                }
			});
			
			$("body").on('click', function(e) {
				if(!$(e.target).closest('.links-hover, [data-iconlink], .amsearch-wrapper-block').length) {
					if(window.isBody != true){
						$('.links-hover').removeClass('opened');
						$('[data-iconlink]').removeClass('active');
						//console.info('----- ');
						if($('.amsearch-result-section').is(":visible")) {
							$('.amsearch-overlay').trigger('click');
							//console.info('++++ ');
						}
					}
				}
			});
		},
		
		_navSwitch: function() {
			mediaCheck({
				media: '(max-width: 992px)',
				entry: $.proxy(function () {
					$('.sections.nav-sections').insertAfter($('.page-header'));
				}, this),
				exit: $.proxy(function () {
					$('.page-header').append($('.sections.nav-sections'));
				}, this)
			});
		},
		
	});
 
    //return $.pf.header;
    $.pf.header();
});