define([
    "jquery",
	"matchMedia",
    "jquery/ui",
    "domReady!",
], function($, mediaCheck) {
    "use strict";
 
    $.widget('pf.footer', {
		
		options: {
			selector: '.footer-col > h4',
            responsive: true,
			back2top: true
        },
		
        _create: function () {
            var self = this;
            this._super();
						
			if (this.options.back2top === true) {
				this._backToTop();
			}
			
			this._dataMobile();
        },

        _init: function () {
            this._super();
            
            if (this.options.responsive === true && this.options.selector != null ) {
				this.selector = this.options.selector;
				mediaCheck({
                    media: '(max-width: 767px)',
                    entry: $.proxy(function () {
                        this._toggleMobileMode();
                    }, this),
                    exit: $.proxy(function () {
                        this._toggleDesktopMode();
                    }, this)
                });
				
				mediaCheck({
                    media: '(max-width: 1024px)',
                    entry: $.proxy(function () {
                        if($('.page-footer .social-links').length) {
							$('.page-footer .social-links').appendTo('.footer .swrap');
						}
                    }, this),
                    exit: $.proxy(function () {
                        if($('.page-footer .social-links').length) {
							$('.page-footer .social-links').appendTo('.footer .footer-col.f1');
						}
                    }, this)
                });
            }
			
			$(document).on('click','.action-hours', function(e) {
				e.preventDefault();
				if( $(this).hasClass('active') ) {
					$(this).removeClass('active').parent().siblings('.hours').removeClass('expanded');
				} else {
					$(this).addClass('active').parent().siblings('.hours').addClass('expanded');
				}
			});
			
			
		},
		
		_toggleDesktopMode: function () {
			$(document).off('click', this.selector);
			$(this.selector).parent().removeClass('active');
		},
		
		_toggleMobileMode: function () {
			$(document).on('click', this.selector, function(e){
				$(this).parent().toggleClass('active');
			});
		},
		
		_backToTop: function() {
			$('body').append('<div id="back2top" role="complementary"><a class="action secondary" href="#" style="display: none"><i class="ic ic-arrow-up"></i><br>top</a></div>');
			
			$(document).on('click', '#back2top > a', function(e){
				e.preventDefault();
				
				$('body,html').animate({
					scrollTop:0
				},800);
			});
			
			$(window).scroll(function(e){
				if($(this).scrollTop() > $(window).height()){
					$('#back2top > a').fadeIn();
				}else{
					$('#back2top > a').fadeOut();
				}
			});
		},
		
		_dataMobile: function () {
			var table = 'body.account #my-orders-table, body.account #additional-addresses-table, .body.physician .physician-table';

			$(table).each(function(i, e) {
				$(e).addClass('mob');
			});
		}
		
	});
 
    //return $.pf.footer;
    $.pf.footer();
});