define([
	'jquery',
	'matchMedia',
	'swiperjs',
	"jquery/ui",
	'equalheightjs',
	'collapsible',
	'accordion',
	'domReady!',
	'fancyboxjs'
], function ($, mediaCheck, Swiper) {
	"use strict";

	var self;

	$.widget('pf.global', {
		options: {
		},
		_create: function () {
			self = this;
		},
		_init: function () {
			self = this;

			if ($('.page-lead').length > 0) {
				$('.page-lead').attr('role', 'complementary');
			}

			$("[data-fancybox]").fancybox({
				infobar: false,
				buttons: false,
				afterLoad: function () {
					$('.fancybox-content').append('<button data-fancybox-close="" class="fancybox-close-small"></button>');
				}
			});

			if (location.hash) {
				//console.log('hash');
				var targetSection = location.hash,
					targetScroll = 0;

				if (targetSection.indexOf('/') !== -1) {
					//console.log(' indexof yes ' + targetSection);
					targetSection = targetSection.slice(0, -1);
					//console.log(' slice yes ' + targetSection);
				}

				if (targetSection.indexOf('=') !== -1) {
					return false;
				}

				targetSection = targetSection + '_section';

				if ($(targetSection).length > 0) {
					//console.log('targetSection');
					targetScroll = $(targetSection).offset().top - $('.page-header').height();
					//console.log('targetScroll ' + targetScroll);
					$('body,html').animate({
						scrollTop: targetScroll
					}, 300);

					if ($(targetSection).is('[data-fancyboxopen]')) {
						$(targetSection + ' a[data-fancybox] ').trigger('click');
						//console.log('targetSection trigger');
					}

					if ($(targetSection).find('[data-role="trigger"]').length) {
						$(targetSection).find('[data-role="trigger"]').trigger('click');
						//console.log('targetSection trigger data role');
					}
				}
			}

			if ($('.cms-menu').length) {
				$('.cms-menu').prepend('<li class="ptoggle"><a href="javascript:void(0)">Menu</a></li>');
				$(document).on('click', '.cms-menu .ptoggle > a', function () {
					$(this).parent().toggleClass('opened');
				});
			}

			$('div[data-title]').each(function () {
				if ($(this).attr('data-title')) {
					$(this).addClass('fx').prepend('<span class="opac" data-bottom-top="transform: translate3d(-50%,0%,0)" data-top-bottom="transform: translate3d(50%,0%,0)">' + $(this).attr('data-title') + '</span>');
				}
			});

			if (!$('body').hasClass('po-enable') && $('.box-section .figure').length > 0) {
				$('.box-section .figure').each(function () {
					if ($(this).is('[data-bg]')) {
						$(this).addClass('--' + $(this).attr('data-bg')).children('span').attr('style', 'background-image: url("' + $(this).find('img').attr('src') + '")');
					}
				});
			}

			if ($('.box-promo .info').length) {
				$('.box-promo .title').responsiveEqualHeightGrid();
				$('.box-promo .description').responsiveEqualHeightGrid();
				$('.box-promo .info').responsiveEqualHeightGrid();
			}

			/*$('.box-atsw5 .atsw-item').on('click', function() {
				if(!$(this).hasClass('active')) {
					$(this).addClass('active').siblings().removeClass('active');
					$(this).parents('.box-atsw5').find('.box-figure > img').attr('src',$(this).find('.figure > img').attr('src'));
					$(this).parents('.box-atsw5').find('.box-title > .sub').text($(this).find('.description > p').text());
				}
			});*/

			/*if ($('.why-wrapper .detail').length) {
				$('.why-wrapper .detail').responsiveEqualHeightGrid();
			}*/

			var whyaveneOpts = {
				slidesPerView: 5,
				spaceBetween: 0,
				breakpoints: {
					320: {
						slidesPerView: 1
					},
					768: {
						slidesPerView: 5
					}
				}
			}
			var whyaveneCarousel = new Swiper('.why-wrapper', whyaveneOpts);

			var discoverThumbsCount = 3;
			if ($('.box-discover2').length) {
				discoverThumbsCount = 6;
			}
			var discoverThumbsOpts = {
				slidesPerView: discoverThumbsCount,
				spaceBetween: 10,
				freeMode: true,
				watchSlidesVisibility: true,
				watchSlidesProgress: true,
				breakpoints: {
					320: {
						slidesPerView: 3
					},
					768: {
						slidesPerView: discoverThumbsCount
					}
				}
			}
			var discoverThumbs = new Swiper('.discover-thumbs', discoverThumbsOpts);
			var discoverMainOpts = {
				slidesPerView: 1,
				spaceBetween: 0,
				navigation: {
					nextEl: '.discover-main .swiper-button-next',
					prevEl: '.discover-main .swiper-button-prev',
				},
				pagination: {
					el: '.discover-main .swiper-pagination',
					clickable: true,
				},
				thumbs: {
					swiper: discoverThumbs
				}
			}
			var discoverMain = new Swiper('.discover-main', discoverMainOpts);

			$(document).on('click', '.products-grid .product-item-attrib > p', function () {
				$(this).parent().toggleClass('expanded');
			});

			//var accordToggle = $(".accord-container").accordion();
			var accordToggle = '.accord-container .accord-title';
			if($(accordToggle).length) {
				$(accordToggle).eq(0).addClass('active').next('.accord-content').slideToggle();
				$(document).on('click', accordToggle, function(e) {
					e.preventDefault();
					$(this).toggleClass('active').next('.accord-content').slideToggle();
					$(this).parent().siblings().find('.accord-title').removeClass('active').next('.accord-content').slideUp();
				});
			}

			var atswOpts = {
				breakpoints: {
					320: {
						slidesPerView: 3
					},
					768: {
						slidesPerView: 6
					}
				}
			}
			var atswCarousel = new Swiper('.atsw-list', atswOpts);
			
			const supportsTouch = ( ('ontouchstart' in window) || (navigator.maxTouchPoints > 0) || (navigator.msMaxTouchPoints > 0) );
			
			if(supportsTouch) {
				$('html').addClass('touch');
			} else {
				$('html').addClass('no-touch');
			}
			
			$(".skin-edu-tips.eh").each(function() {
				let item = $(this).find('.tips-item');
				let count = Math.round(item.length/2);
				//alert(count);
				for(let i = 0; i < count; i++) {
					let _this = $(this);
					$(this).find('.col:first-child .tips-item').eq(i).addClass('eh'+i);
					$(this).find('.col:not(:first-child) .tips-item').eq(i).addClass('eh'+i);
					setTimeout(function() {
						_this.find('.eh'+i).responsiveEqualHeightGrid();
					},100);
				}
			});
			
			if( $('.giftguide-tabs li').length > 0 ) {
				$(document).on('click', '.giftguide-tabs li > a', function(e) {
					e.preventDefault();
					let giftItem = ($(this).parent().index()*1)+1,
						giftScroll = $('#giftguide_'+giftItem).offset().top - $('.page-header').height();
					$(this).addClass('active').parent().siblings().find('a').removeClass('active');
					$('body,html').animate({
						scrollTop: giftScroll
					}, 300);
				});
			}
			
			if( $('.box-sptext').length && $('.box-spalpha').length ) {
				const alpha = ["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"];
				let alphaKey = [], alphaFlag = '', alphaChar, alphaScroll, alphaLink;
				$('.box-sptext .spara h4').each(function() {
					alphaChar = $(this).text().charAt(0);
					if(alphaFlag !== alphaChar) {
						$(this).parent().prepend('<div class="split" id="'+alphaChar+'">&nbsp;</div>');
					}
					alphaFlag = alphaChar;
					alphaKey.push(alphaChar);
				});
				$.unique(alphaKey);
				$.each( alpha, function(i,v) {
					alphaLink = '<span>'+v+'</span>';
					if($.inArray(v, alphaKey) !== -1)
					{
					  alphaLink = '<a href="#'+v+'">'+v+'</a>';
					}
					$('.box-spalpha .box-content').append('<li>'+alphaLink+'</li>');
				});
				$('.box-spalpha li').wrapAll('<ul>');
				$(document).on('click', '.box-spalpha li a', function(e) {
					e.preventDefault();
					alphaScroll = $($(this).attr('href')).offset().top - $('.page-header').height() - 10;
					$('body,html').animate({
						scrollTop: alphaScroll
					}, 1);
				});
			}
			//return false;
		}
	});

	//return $.pf.global;
	$.pf.global();
});