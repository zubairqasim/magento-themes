define([
    "jquery",
	"matchMedia",
    "masonryjs",
	"jquery/ui",
    "domReady!"
], function($, mediaCheck, Masonry) {
    "use strict";

    //Creating PF Slider Widget
    $.widget('pf.masonry', {
		
		options: {
            selector: null,
        },
		
        _create: function () {
            var self = this;
			//this._super();
			
			//alert('createeeeeeee');
        },

        _init: function () {
			//this._super();
			alert('pf.masonry widget init');
		}
	});
 
    //return $.pf.masonry;
});