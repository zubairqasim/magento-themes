var config = {
    config: {
        mixins: {
            'Magento_SalesRule/js/view/summary/discount': {
                'Magento_SalesRule/js/view/summary/discount-mixin': true
            },
        }
    }
};
