define([], function () {
    'use strict';
    return function (Component) {
        return Component.extend({
            getTitle: function () {
                var self = this;
                if( window.hideP2PCoupons == 1 && window.p2pCodes != 0){

                    var discountSegments;

                    if (!this.totals()) {
                        return null;
                    }

                    discountSegments = this.totals()['total_segments'].filter(function (segment) {
                        return segment.code.indexOf('discount') !== -1;
                    });

                    if(discountSegments.length) {
                        return self.filterDiscountCodes(discountSegments[0].title);
                    } else {
                        return null;
                    }
                } else {
                    var discountSegments;

                    if (!this.totals()) {
                        return null;
                    }


                    discountSegments = this.totals()['total_segments'].filter(function (segment) {
                        return segment.code.indexOf('discount') !== -1;
                    });
                    return discountSegments.length ? discountSegments[0].title : null;
                }
            },

            filterDiscountCodes:  function(discountCodes) {
                var start = discountCodes.indexOf("("),
                    end = discountCodes.indexOf(")"),
                    couponCodesString = (start > -1 && end > -1 ) ? discountCodes.substring(start+1, end): 'Discount';

                var finalCoupons = [];
                if(couponCodesString != 'Discount'){
                    var coupons = couponCodesString.split(',');
                    coupons.forEach(function(value, index){
                        if( window.p2pCodes.indexOf(value.toLowerCase().trim()) === -1){
                            finalCoupons.push(value);
                        }
                    });
                    return (finalCoupons.length > 0) ? 'Discount '+finalCoupons.join(','): 'Discount';
                }
                return couponCodesString;
            }
        });
    }
});
