var config = {
    config: {
        mixins: {
            'Amasty_Scroll/js/amscroll': {
                'Amasty_Scroll/js/amscroll-mixin': true
            },
        }
    }
};
