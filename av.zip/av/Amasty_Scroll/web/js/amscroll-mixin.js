define([
    'jquery',
    'jquery/ui'
], function ($) {
    'use strict';

    return function (widget) {
        var self = this;
		
        $.widget('mage.amScrollScript', widget, {
            _create: function () {
                self = this;
                self._super();
				
            },

            _afterShowFollowing: function () {
                self = this;
                var nextPage = $(self.pagesLoaded).get(-1) + 1;//last + 1
                if (nextPage && nextPage <= self.pagesCount && $.inArray(nextPage, self.pagesLoaded) == -1) {
                    self.next_data_url = self._generateUrl(nextPage, 1);
                    self.pagesLoaded.push(nextPage);
                    var self = this;
                    self.flag_next_cache = 1;
                    $.getJSON(self.next_data_url, function (preview_data) {
                        self.flag_next_cache = 0;
                        self.next_data_cache = preview_data;
                        $(window).scroll();
                    });
                }

                /**
                 * Cdigital
                 *
                 * Yotpo Initialization
                 */
                if( typeof yotpo !== 'undefined'){
                    var api = new Yotpo.API(yotpo);
                    api.refreshWidgets();

                }
                self.is_loading = 0;
                return self._super();
            },

            _afterShowPrevious: function () {
                self = this;
                var prevPage = $(self.pagesLoaded).get(0) - 1;
                if (prevPage && prevPage >= 1 && $.inArray(prevPage, self.pagesLoaded) == -1) {
                    self.prev_data_url = self._generateUrl(prevPage, 1);
                    self.pagesLoaded.unshift(prevPage);
                    var self = this;
                    self.flag_prev_cache = 1;

                    $.getJSON(self.prev_data_url, function (preview_data) {
                        self.flag_prev_cache = 0;
                        self.prev_data_cache = preview_data;
                        $(window).scroll();
                    });
                }
                /**
                 * Cdigital
                 *
                 * Yotpo Initialization
                 */
                if( typeof yotpo !== 'undefined'){
                    var api = new Yotpo.API(yotpo);
                    api.refreshWidgets();

                }
                self.is_loading = 0;
            }
        });
        return $.mage.amScrollScript;
    }
});
