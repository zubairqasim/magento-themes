define([
    'jquery',
	'mage/translate',
    'jquery/ui',
], function ($, $t) {
    'use strict';

    return function (widget) {
		var self,
			minicartCounter,
			parentBody = window.parent.document.body;
		
		$.widget('mage.catalogAddToCart', widget, {
			options: {
				processStart: null,
				processStop: null,
				bindSubmit: true,
				minicartSelector: '[data-block="minicart"]',
				messagesSelector: '[data-placeholder="messages"]',
				productStatusSelector: '.stock.available',
				addToCartButtonSelector: '.action.tocart',
				addToCartButtonDisabledClass: 'disabled',
				addToCartButtonDisabledClass2: 'is-disabled',
				addToCartButtonTextWhileAdding: '',
				addToCartButtonTextAdded: '',
				addToCartButtonTextDefault: '',
				minicartShowed: false,
				noOfRequest: 1,
				timer: null
			},
			_create: function () {
				self = this;
				if (self.options.bindSubmit) {
					self._bindSubmit();
				}
				if( !$('body').hasClass('catalog-product-view') ) {
					$(self.options.addToCartButtonSelector).attr('disabled', false);
				}
			},
			disableAddToCartButton: function (form) {
				self = this;
				var addToCartButtonTextWhileAdding = this.options.addToCartButtonTextWhileAdding || $t('Adding...');
				var addToCartButton = $(form).find(this.options.addToCartButtonSelector);
				addToCartButton.addClass(this.options.addToCartButtonDisabledClass);
				addToCartButton.find('span').text(addToCartButtonTextWhileAdding);
				addToCartButton.attr('title', addToCartButtonTextWhileAdding);
				
				//regimen button pdp, on adding
				var addToCartButtonRegimen = $('#add-all-to-cart');
				addToCartButtonRegimen.addClass(this.options.addToCartButtonDisabledClass);
				addToCartButtonRegimen.find('span').text(addToCartButtonTextWhileAdding);
				addToCartButtonRegimen.attr('title', addToCartButtonTextWhileAdding);
			},
			enableAddToCartButton: function (form) {
				self = this;
				self._super(form);
				console.warn('enable-addtocart mixin');
				
				var addToCartButtonTextAdded = self.options.addToCartButtonTextAdded || $t('Added');
				var addToCartButton = $(form).find(self.options.addToCartButtonSelector);

				addToCartButton.find('span').text(addToCartButtonTextAdded);
				addToCartButton.attr('title', addToCartButtonTextAdded);

				setTimeout(function() {
					var addToCartButtonTextDefault = self.options.addToCartButtonTextDefault || $t('Add to Bag');
					addToCartButton.removeClass(self.options.addToCartButtonDisabledClass);
					addToCartButton.find('span').text(addToCartButtonTextDefault);
					addToCartButton.attr('title', addToCartButtonTextDefault);

					//regimen button pdp, after adding
					var addToCartButtonRegimen = $('#add-all-to-cart');
					addToCartButtonRegimen.removeClass(self.options.addToCartButtonDisabledClass);
					addToCartButtonRegimen.find('span').text('Add Regimen to Bag');
					addToCartButtonRegimen.attr('title', 'Add Regimen to Bag');                
				}, 1000);
				
				if(!$(parentBody).find('iframe.mfp-iframe').length) {
					minicartCounter = true;
					console.warn('minicart open ' + minicartCounter);
					$('[data-iconlink="topcart"]:not(.active)').trigger('click');
					$('[data-role="loader-minicart"]').show();
					$(self.options.minicartSelector).on('contentUpdated', function(){
						//console.warn('minicart Updated');
						if( minicartCounter != false){
							minicartCounter = false;
							$('[data-role="loader-minicart"]').hide();
							//console.warn('minicart loader removed');
							setTimeout(function(){
								$('[data-iconlink="topcart"].active').trigger('click');
								console.warn('minicart close');
							}, 5000);
						}
					});
				}
			}
		});

		return $.mage.catalogAddToCart;
	}
});