/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

/**
 * @api
 */
define([
    '../model/quote',
    'jquery'
], function (quote, $) {
    'use strict';

    function checkAndSetShippingMethod() {
        if ($('input[id^="s_method_"]').length > 0) {

            var flagSelectedShippingMethod = false;
            $('input[id^="s_method_"]').each(function () {
                if ($(this).is(':checked')) {
                    flagSelectedShippingMethod = true;
                }
            });

            if (flagSelectedShippingMethod == true) {
                console.log(' Custom work =>  cart page-1 => skips, set shipping method logic');
                return true;
            }

            var count = 1;
            $('input[id^="s_method_"]').each(function (k, v) {
                if (count++ == 1) {
                    $(this).attr('checked', true).trigger('click');
                    console.log(' Custom work => cart page-1 => success, set shipping method logic');
                    return false; // breaks execution
                }
            });
        }
    };

    return function (shippingMethod) {
        if (shippingMethod == null) {
            /*
            * custom work,
            * if shipping methods are rendering,
            * select the first one
            * */
            checkAndSetShippingMethod();
        }
        quote.shippingMethod(shippingMethod);
    };
});
