
/**
 * Copyright © 2013-2017 Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
define([
    'jquery',
    'ko',
    'underscore',
    'pf_helper'
], function ($, ko, _, pf_helper) {
    'use strict';

    return function (Component) {
        return Component.extend({
            helper: function(){
                return pf_helper({});
            },

            getCrosssellAmount: function (name) {
                var crosssellAmount = 0;
                if (!_.isUndefined(name)) {
                    if (!this.cart.hasOwnProperty(name)) {
                        this.cart[name] = ko.observable();
                    }

                    if(name == 'crosssellamount' && this.cart[name]() != undefined) {
                        crosssellAmount = this.cart['crosssellamount']();
                    }
                }
                return crosssellAmount;
            },

            getMiniCartShippingMsg: function (name='qualify_for_free_shipping_msg') {
                var show = 0;
                if (!_.isUndefined(name)) {
                    if (!this.cart.hasOwnProperty(name)) {
                        this.cart[name] = ko.observable();
                    }

                    if(name == 'qualify_for_free_shipping_msg' && this.cart[name]() != undefined) {
                        show = this.cart['qualify_for_free_shipping_msg']();
                    }

                    if(name == 'qualified_free_shipping_msg' && this.cart[name]() != undefined) {
                        show = this.cart['qualified_free_shipping_msg']();
                    }

                    if(name == 'standard_free_shipping_msg' && this.cart[name]() != undefined) {
                        show = this.cart['standard_free_shipping_msg']();
                    }

                    if(name == 'standard_msg' && this.cart[name]() != undefined) {
                        show = this.cart['standard_msg']();
                    }

                    if(name == 'qualify_msg' && this.cart[name]() != undefined) {
                        show = this.cart['qualify_msg']();
                    }

                    if(name == 'qualified_msg' && this.cart[name]() != undefined) {
                        show = this.cart['qualified_msg']();
                    }
                }
                return show;
            },

            freeShippingApplied: function(name = 'freeShippingApplied'){
                var freeShippingApplied = 0;
                if (!_.isUndefined(name)) {
                    if (!this.cart.hasOwnProperty(name)) {
                        this.cart[name] = ko.observable();
                    }

                    if(name == 'freeShippingApplied' && this.cart[name]() != undefined) {
                        freeShippingApplied = this.cart['freeShippingApplied']();
                    }
                }
                return freeShippingApplied;
            },

            getCartParamTotal: function (name) {
                if (!_.isUndefined(name)) {
                    if (!this.cart.hasOwnProperty(name)) {
                        this.cart[name] = ko.observable();
                    }

                    // if(window.location.href.indexOf("checkout") > -1 && window.location.href.indexOf("cart") > -1) {
                    // 	return 'cart-page';
                    // }

                    var subTotal = this.cart[name]();

                    if(parseInt(subTotal) == 0) {
                        return parseInt(subTotal);
                    }

                    return subTotal;
                }
            },

            checkCartPage: function () {
                var currentUrl = window.location.href;
                if (currentUrl.toLowerCase().indexOf("checkout") != -1 || currentUrl.toLowerCase().indexOf("cart") != -1) {
                    return true;
                }
                return false;
            },

            scrollCart: function () {
                $('html,body').animate({
                    scrollTop: $('.form-cart').offset().top - 60
                },'slow');
            },

            getDifferenceAmount: function (name) {
                if (!_.isUndefined(name)) {
                    if (!this.cart.hasOwnProperty(name)) {
                        this.cart[name] = ko.observable();
                    }

                    var subTotal = this.cart[name]();

                    if(parseFloat(subTotal) < parseFloat(this.getCrosssellAmount('crosssellamount'))) {
                        var awayAmount = subTotal - this.getCrosssellAmount('crosssellamount');
                        awayAmount = Math.abs(awayAmount);
                        awayAmount = awayAmount.toFixed(2);
                        return awayAmount;
                    }

                    return false;
                }
            },

            getCookie: function(cookieName){
                var self = this;
                return self.helper().getCookie(cookieName);
            }
        });
    }
});
