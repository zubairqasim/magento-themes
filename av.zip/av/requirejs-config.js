var config = {
	map: {
        '*' : {
            'pf_global'			: 'js/pf.global',
            'pf_header'			: 'js/pf.header',
            'pf_footer'			: 'js/pf.footer',
			'pf_scrolling'		: 'js/pf.scroll',
			'pf_slider' 		: 'js/pf.slick',
			'pf_masonry'		: 'js/pf.masonry',
            'pf_helper'	        : 'js/pf.helper'
        }
    },
	paths: {
		'slickjs'		: 'js/vendor/slick',
		'swiperjs'		: 'js/vendor/swiper',
		'fancyboxjs'	: 'js/vendor/fancybox',
		'equalheightjs'	: 'js/vendor/equalheights.responsive',
		'masonryjs'		: 'js/vendor/masonry'
    },
	shim: {
		pf_masonry: {
            deps: [
                'jquery',
                'masonryjs'
            ]
        },
		pf_global: {
            deps: [
                'jquery'
            ]
        },
		pf_header: {
            deps: [
                'jquery'
            ]
        },
		pf_footer: {
            deps: [
                'jquery'
            ]
        },
		pf_slider: {
            deps: [
                'jquery',
                'slickjs'
            ]
        },
		swiperjs: {
            deps: [
				'jquery'
			]
        },
		fancyboxjs: {
            deps: [
				'jquery'
			]
        },
		equalheightjs: {
            deps: [
				'jquery'
			]
        }
    },
	deps: [
		'pf_header',
		'pf_footer',
		'pf_global',
		'pf_scrolling'
	]
};
