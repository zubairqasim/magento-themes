define([
    'jquery',
    'mage/translate',
    'Magento_Customer/js/model/customer',
    'pf_helper',
    'jquery/validate',
    'jquery/ui',
    'fancyboxjs'
], function($, $t, $customer, helper){
    "use strict";

    $.widget('pf.p2p', {
        helper: helper({}),
        options: {
            utm_source: null,
            utm_medium: null,
            prepare_head_shots_overlay_url: null,
            head_shots_overlay_id: null,
            unlock_offer_overlay_id: null,
            head_shot_click_class: null,
            create_connection_url: null,
            staff_id_section: null,
            staff_id_checkbox: null,
            unlock_offer_submit_id: null,
            unlock_offer_form_id: null,
            staff_id_drop_down: null,
            staff_id_field: null,
            cancel_offer_id: null,
            go_back_id: null,
            reload_with_params: 0,
            js_error_log: 0,
            staff_id_checkbox_section_id: null,
            cookieExpiryTime: 30,
            cookieName: 'p2p_customer',
            cookieNameWithEmail: 'p2p_customer_with_email',
            staffIdDropDown: "#staff_id_select",
            base_url: null,
			base_ref_url:null,
            loader_id: null,
            success_url: null
        },

        _create: function () {
            var self = this;
            this._super();
        },

        _init: function () {
            var self = this;
            if( self.helper.getCookie("offer_unlocked") !== false){
                //adding css class to body in case the current
                //customer is p2p
                $('body').addClass('is-p2p');
                ( $customer.isLoggedIn() == false ) ? $('body').addClass('is-p2p-out') : $('body').addClass('is-p2p-in');
            }

            if(
                self.options.utm_source !== null &&
                self.options.utm_medium !== null &&
                self.options.prepare_head_shots_overlay_url !== null
            ) {
                self.options.isSecondOverlay = false;

                var utm_medium = self.getParam(self.options.utm_medium);
                if( utm_medium && utm_medium.toLowerCase().indexOf('p2p') != -1 && self.helper.getCookie("offer_unlocked") === false){
                    var utm_source = self.getParam(self.options.utm_source);
                    if(
                        typeof utm_source === 'string' &&
                        utm_source != ''
                    ){
                        self.prepareHeadShotsOverlay(
                            utm_source.toLowerCase(),
                            utm_medium,
                            self.options.prepare_head_shots_overlay_url
                        );
                    }



                    //head shot click event
                    $(document).on('click', self.options.head_shot_click_class, function(){
                        var physicianId = $(this).attr("id");
                        var params = $("#params_"+physicianId).val();
                        self.options.params = JSON.parse(params);

                        //create connection with the physician
                        self.createConnection();
                    });

                    //binding staff id checkbox click event
                    $(document).on("click", self.options.staff_id_checkbox, function(){
                        if( $(this).is(":checked") ){
                            $(self.options.staff_id_section).show();
                        } else {
                            $(self.options.staff_id_drop_down).prop("selectedIndex", 0);
                            $(self.options.staff_id_field).val("");
                            $(self.options.staff_id_section).hide();
                        }
                    });


                    //binding form submit
                    $(document).on("click", self.options.unlock_offer_submit_id, function(){
                        if( self.isValid() === true ){
                            self.unlockOffer();
                        }
                    });

                    //binding staff drop down change event
                    $(document).on("change", self.options.staff_id_drop_down, function(){
                        $(self.options.staff_id_field).val($(this).val());
                    });

                    //binding cancel offer event
                    $(document).on("click", self.options.cancel_offer_id, function(){
                        self.cancelOffer(self.options.unlocked_id);
                    });

                    //binding go back event
                    $(document).on("click", self.options.go_back_id, function(){
                        self.goBack(self.options.unlocked_id);
                    });

                    //adding css class to body in case the current
                    //customer is p2p
                    $('body').addClass('is-p2p');
                }
            }
            this._super();
        },

        prepareHeadShotsOverlay: function(utm_source, utm_medium, requestUrl){
            var self = this;
            $.ajax({
                url: requestUrl,
                dataType: 'JSON',
                type: 'POST',
                data: { utm_source: utm_source, utm_medium: utm_medium },
                success: function(response){
                    if( response.success == true && response.result != false ) {

                        //triggering main head shots popup
                        $(self.options.head_shots_overlay_id).html(response.result.head_shots_overlay);

                        if( self.helper.getCookie("offer_unlocked") === false){
                            $.fancybox.open($(self.options.head_shots_overlay_id));
                        }

                        //appending unlock offer html
                        $(self.options.unlock_offer_overlay_id).html(response.result.unlock_offer_overlay);

                    } else if( response.success == false ) {
                        self.logError(response.message);
                    }
                },
                error: function(response){
                    self.logError(response.message);
                },
                always: function(){}
            });
        },

        goBack: function(offerId = 0){
            var self = this;
            if( self.options.offer_cancel_url !== null ){
                $.ajax({
                    url: self.options.offer_cancel_url,
                    dataType: 'JSON',
                    type: 'GET',
                    data: { offer_id:  offerId, go_back: 1},
                    success: function(response){
                        if( response.success == true && response.go_back == true){
                            $.fancybox.close();
                            $.fancybox.open($(self.options.head_shots_overlay_id));
                        }

                        if( response.error == true && response.success != true){
                            self.logError(response.message);
                        }
                    },
                    error: function(response){
                        self.logError(response.message);
                    },
                    always(){}
                });
            }
        },

        cancelOffer: function(offerId = 0){
            var self = this;
            if( self.options.offer_cancel_url !== null ){
                $.ajax({
                    url: self.options.offer_cancel_url,
                    dataType: 'JSON',
                    type: 'GET',
                    data: { offer_id:  offerId},
                    success: function(response){
                        if( response.success == true){
                            self.logSuccess(response.message);
                            self.helper.setCookie(self.options.cookieName, false, 0.5, 'seconds');
                            self.helper.setCookie('offer_unlocked', false, 0.5, 'seconds');
                            self.helper.setCookie('p2p_customer_email', false, 0.5, 'seconds');
                            $.fancybox.close();
                            //window.location.href = self.options.base_url;
                            if(self.options.success_url != null){
                                self.callSuccess();
								window.location.href = self.options.base_ref_url;
                                // window.history.pushState("", "", '/');
                                // window.location.reload(true);
                            } else {
                                window.history.pushState("", "", '/');
                                window.location.reload(true);
                            }
                        }

                        if( response.error == true && response.success != true){
                            self.logError(response.message);
                        }
                    },
                    error: function(response){
                        self.logError(response.message);
                    },
                    always(){}
                });
            }
        },

        unlockOffer: function(){
            var self = this;
            var form = $(self.options.unlock_offer_form_id);
            self.options.isSecondOverlay = true;
            self.options.params.email = form.find('input[name="email"]').val();
            self.options.params.staff_id = form.find('input[name="staff_id"]').val();
            self.options.params.unlockoffer = true;
            $(self.options.loader_id).show();
            self.createConnection();
        },

        triggerUnlockOfferPopup: function(){
            var self = this;
            $.fancybox.close();
            $.fancybox.open($(self.options.unlock_offer_overlay_id),{
                touch: false,
                afterShow: function(ins,cur) {
                    if($(cur.$content).find('.pp-figure img').length) {
                        $(cur.$content).find('.pp-figure').css({'background-image':'url('+$(cur.$content).find('.pp-figure img').attr('src')+')','opacity': 1});
                    }
                }
            });
        },

        createConnection: function(){
            var self = this;
            $.ajax({
                url: self.options.create_connection_url,
                type    : "POST",
                dataType: "JSON",
                data: self.options.params,
                success: function(response){
                    if( response.success == true ){
                        if( response.cookie_value != ''){
                            self.helper.setCookie(self.options.cookieName, response.cookie_value, self.options.cookieExpiryTime);
                        }

                        if( response.p2p_customer_email != ''){
                            self.helper.setCookie('p2p_customer_email', response.p2p_customer_email, self.options.cookieExpiryTime);
                        }
                        self.logSuccess(response.message);

                        if( self.options.isSecondOverlay == false ){
                            $(self.options.staff_id_checkbox_section_id).show();
                            self.triggerUnlockOfferPopup();
                            if( response.staff_members != false && response.staff_members != ''){
                                $(self.options.staff_id_section).html(response.staff_members);
                            } else {
                                $(self.options.staff_id_checkbox_section_id).hide();
                            }
                        }

                        if(
                            response.has_unlocked_offer == true &&
                            self.options.isSecondOverlay == true
                        ){
                            $(self.options.loader_id).hide();
                            $.fancybox.close();
                            self.helper.setCookie('offer_unlocked', 1, self.options.cookieExpiryTime);
                            if(self.options.success_url != null){
                                self.callSuccess();
                                // window.history.pushState("", "", '/');
                                // window.location.reload(true);
                            } else {
                                window.history.pushState("", "", '/');
                                window.location.reload(true);
                            }


                            //window.location.replace(self.options.params.base_url);
                        }

                        //adding unlocked offer id in the params
                        //in case user clicks the no thanks anchor
                        if( response.unlocked_id > 0){
                            self.options.unlocked_id = response.unlocked_id;
                            self.options.params.unlocked_id = response.unlocked_id;
                        }
                    }

                    if( response.error == true && response.success != true ){
                        self.logError(response.message);
                    }
                },
                error: function(response){
                    if( response.error == true && response.success != true ){
                        self.logError(response.message);
                    }
                },
                always: function(){
                    $(self.options.loader_id).hide();
                }
            });
        },

        callSuccess: function(){
            var self = this;
            $.ajax({
                url: self.options.success_url,
                type    : "GET",
                dataType: "JSON",
                data: {},
                success: function(response){
					window.location.href = self.options.base_ref_url;
                    //window.history.pushState("", "", '/');
                    //window.location.reload(true);
                },
                error: function(response){}
            });
        },

        getParam: function(name, url){
            if (!url) url = window.location.href;
            name = name.replace(/[\[\]]/g, '\\$&');
            var regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'),
                results = regex.exec(url);
            if (!results) return null;
            if (!results[2]) return '';
            return decodeURIComponent(results[2].replace(/\+/g, ' '));
        },

        logError: function(message = ''){
            console.error(message);
        },

        logSuccess: function(message = ''){
            console.log('P2P Success Message: ' + message);
        },

        randomLogMessage(message = ''){
            console.log( message);
        },

        isValid: function () {
            var self = this;
            return $(self.options.unlock_offer_form_id).valid();
        }

    });
    return $.pf.p2p;
});
