define([
    'jquery',
    'mage/translate',
    'Magento_Customer/js/model/customer',
    'pf_helper',
    'jquery/validate',
    'fancyboxjs'
], function($, $t, $customer, helper){
    "use strict";

    $.widget('pf.p2pexpress', {
        helper: helper({}),
        options: {
            utm_source: null,
            utm_medium: null,
            prepare_head_shots_overlay_url: null,
            head_shots_overlay_id: null,
            unlock_offer_overlay_id: null,
            head_shot_click_class: null,
            create_connection_url: null,
            staff_id_section: null,
            staff_id_checkbox: null,
            unlock_offer_submit_id: null,
            unlock_offer_form_id: null,
            staff_id_drop_down: null,
            staff_id_field: null,
            cancel_offer_id: null,
            go_back_id: null,
            reload_with_params: 0,
            js_error_log: 0,
            staff_id_checkbox_section_id: null,
            cookieExpiryTime: 30,
            cookieName: 'p2p_customer',
            cookieNameWithEmail: 'p2p_customer_with_email',
            staffIdDropDown: "#staff_id_select",
            base_url: null,
			base_ref_url:null,
            include_payload_url: false,
            params: {},
            loader_id: null,
            success_url: null
        },

        _create: function () {
            var self = this;
            this._super();
        },

        _init: function () {
            var self = this;

            if( self.getCookie("offer_unlocked") == 1){
                //adding css class to body in case the current
                //customer is p2p
                $('body').addClass('is-p2p');
                if( $customer.isLoggedIn() == false ){
                    $('body').addClass('is-p2p-out');
                } else {
                    $('body').addClass('is-p2p-in');
                }
            }

            if(
                typeof self.options.utm_source === 'string' &&
                self.options.utm_source != '' &&
                typeof self.options.utm_medium === 'string' &&
                self.options.utm_medium != '' &&
                self.getCookie("offer_unlocked") == ''
            ) {
                $.fancybox.open($(self.options.unlock_offer_overlay_id),{
					touch: false,
					afterShow: function(ins,cur) {
						if($(cur.$content).find('.pp-figure img').length) {
							$(cur.$content).find('.pp-figure').css({'background-image':'url('+$(cur.$content).find('.pp-figure img').attr('src')+')','opacity': 1});
						}
					}
				});

                //binding form submit
                $(document).on("click", self.options.unlock_offer_submit_id, function(){
                    if( self.isValid() === true ){
                        self.unlockOffer();
                    }
                });

                //binding cancel offer event
                $(document).on("click", self.options.cancel_offer_id, function(){
                    self.cancelOffer();
                });
            }
            this._super();
        },

        cancelOffer: function(){
            var self = this;
            self.helper.setCookie(self.options.cookieName, '', self.options.cookieExpiryTime);
            self.helper.setCookie('offer_unlocked', '', self.options.cookieExpiryTime);
            self.helper.setCookie('p2p_customer_email', '', self.options.cookieExpiryTime);
            //window.location.replace(self.options.base_url);
            if(self.options.success_url != null){
                self.callSuccess();
				window.location.href = self.options.base_ref_url;
                // window.history.pushState("", "", '/');
                // window.location.reload(true);
            } else {
                window.history.pushState("", "", '/');
                window.location.reload(true);
            }

        },

        unlockOffer: function(){
            var self = this;
            var form = $(self.options.unlock_offer_form_id);
            self.options.params.email = form.find('input[name="email"]').val();
            self.options.params.staff_id = form.find('input[name="staff_id"]').val();
            self.options.params.unlockoffer = true;
            self.options.params.params = form.find('input[id="params"]').val();
            self.createConnection();
        },

        createConnection: function(){
            var self = this;
            $(self.options.loader_id).show();
            $.ajax({
                url: self.options.create_connection_url,
                type    : "POST",
                dataType: "JSON",
                data: self.options.params,
                cache: false,
                success: function(response){
                    if( response.success == true ){
                        if( response.cookie_value != ''){
                            self.helper.setCookie(self.options.cookieName, response.cookie_value, self.options.cookieExpiryTime);
                            $(self.options.loader_id).hide();
                            $.fancybox.close();
                            self.helper.setCookie('offer_unlocked', 1, self.options.cookieExpiryTime);
                            if(self.options.success_url != null){
                                self.callSuccess();
                                // window.history.pushState("", "", '/');
                                // window.location.reload(true);
                            } else {
                                window.history.pushState("", "", '/');
                                window.location.reload(true);
                            }
                            //window.location.replace(self.options.base_url);
                        }

                        if( response.p2p_customer_email != ''){
                            self.helper.setCookie('p2p_customer_email', response.p2p_customer_email, self.options.cookieExpiryTime);
                        }
                    }
                },
                error: function(response){
                    if( response.error == true && response.success != true ){
                        console.log(response.message);
                    }
                },
                always: function(){
                    $(self.options.loader_id).hide();
                }
            });
        },

        /**
         * Set cookie for one month for
         * newsletter popup
         *
         * @param {String} cookieName
         * @param {Number | String} cookieValue
         * @param {Number} exdays (no of expiry days)
         */
        setCookie: function(cookieName, cookieValue, cookieExpDays){
            var d = new Date();
            d.setTime(d.getTime() + (cookieExpDays*24*60*60*1000));
            var expires = "expires="+ d.toUTCString();
            document.cookie = cookieName + "=" + cookieValue + ";" + expires + ";path=/";
        },

        /**
         * Get cookie by cookie name
         *
         * @param {String} cookieName
         */
        getCookie: function(cookieName){
            var name = cookieName + "=";
            var decodedCookie = decodeURIComponent(document.cookie);
            var ca = decodedCookie.split(';');
            for(var i = 0; i <ca.length; i++) {
                var c = ca[i];
                while (c.charAt(0) == ' ') {
                    c = c.substring(1);
                }
                if (c.indexOf(name) == 0) {
                    return c.substring(name.length, c.length);
                }
            }
            return "";
        },

        callSuccess: function(){
            var self = this;
            $.ajax({
                url: self.options.success_url,
                type    : "GET",
                dataType: "JSON",
                data: {},
                success: function(response){
					window.location.href = self.options.base_ref_url;
                    //window.history.pushState("", "", '/');
                    //window.location.reload(true);
                },
                error: function(response){}
            });
        },

        getParam: function(name, url){
            if (!url) url = window.location.href;
            name = name.replace(/[\[\]]/g, '\\$&');
            var regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'),
                results = regex.exec(url);
            if (!results) return null;
            if (!results[2]) return '';
            return decodeURIComponent(results[2].replace(/\+/g, ' '));
        },

        isValid: function () {
            var self = this;
            return $(self.options.unlock_offer_form_id).valid();
        }

    });

    return $.pf.p2pexpress;
});
