define([
        'jquery',
        'pf_helper',
        'uiComponent',
        'ko',
        'Magento_Customer/js/customer-data'
    ], function (
    $,
    pf_helper,
    Component,
    ko,
    customerData
    ) {
        'use strict';
        return Component.extend({
            defaults: {
                promoMsg: ko.observable(null),
                url: ko.observable(null),
                isVisible: ko.observable(false),
                helper: pf_helper({}),
                n: ko.observable(0),
                pid: ko.observable(0)
            },

            initialize: function () {
                var self = this;
                this._super();
                $('#shippingLabel').show();
                $('#promobarMessage').hide();

                if(self.n() > 0 && self.pid() > 0){
                    self.initializeP2PUser();
                } else {
                    this.getMessage();
                }
            },

            initObservable: function () {
                this._super()
                    .observe([
                        'n',
                        'pid'
                    ]);
                return this;
            },

            initializeP2PUser: function(){
                var self = this;
                if(self.url){
                    $.ajax({
                        url: self.url,
                        data: {initUser: true, npi: self.n(), pid: self.pid() },
                        dataType: 'JSON',
                        type: 'GET',
                        success: function(response){
                            if(
                                response.success === true &&
                                self.getCookie('offer_unlocked') &&
                                response.error === false
                            ){
                                self.promoMsg(response.message);
                                $('#shippingLabel').hide();
                                $('#promobarMessage').show();
                            }

                            if(response.error === true ){
                                $('#shippingLabel').show();
                            }
                        },
                        error: function(response){}
                    });
                }
            },

            getMessage: function(){
                var self = this;
                if(self.url){
                    $.ajax({
                        url: self.url,
                        data: {p2p_customer: (self.getCookie('p2p_customer') !== false) ? self.getCookie('p2p_customer'):'' },
                        dataType: 'JSON',
                        type: 'GET',
                        success: function(response){
                            if(
                                response.success === true &&
                                self.getCookie('offer_unlocked') &&
                                response.error === false
                            ){
                                self.promoMsg(response.message);
                                $('#shippingLabel').hide();
                                $('#promobarMessage').show();
                            }

                            if(response.error === true ){
                                $('#shippingLabel').show();
                            }
                        },
                        error: function(response){}
                    });
                }
            },

            getCookie: function(cname){
                return this.helper.getCookie(cname);
            }
        });
    }
);
