/*global define*/
define(
    [
        'jquery',
        'Magento_Checkout/js/view/shipping',
        'Magento_Customer/js/model/customer',
        'Amazon_Payment/js/model/storage',
        'Amazon_Payment/js/messages'
    ],
    function (
        $,
        Component,
        customer,
        amazonStorage,
        amazonMessages
    ) {
        'use strict';

        return Component.extend({
            noShippingAddressSelectedMsg: 'No shipping address has been selected for this order, please try to refresh the page or add a new shipping address in the Address Book widget.',

            /**
             * Initialize shipping
             */
            initialize: function () {
                this._super();
                this.isNewAddressAdded(amazonStorage.isAmazonAccountLoggedIn());
                amazonStorage.isAmazonAccountLoggedIn.subscribe(function (value) {
                    this.isNewAddressAdded(value);
                }, this);
				
				/*
				 Quick Fix (08/06/2021)
				 Set email address field
				*/
				var amzInterval = setInterval(function () {
					if($('#amazon-email-address').length) {
						$('#customer-email').val($.trim($('#amazon-email-address').text()));
						console.info('set amz email');
						clearInterval(amzInterval);
					}
				},500);
				
                return this;
            },

            /**
             * Validate guest email
             */
            validateGuestEmail: function () {
                var loginFormSelector = 'form[data-role=email-with-possible-login]';

                $(loginFormSelector).validation();

                return $(loginFormSelector + ' input[type=email]').valid();
            },

            /**
             * Overridden validateShippingInformation for Amazon Pay to bypass validation
             *
             * @inheritDoc
             */
            validateShippingInformation: function () {
                if (!amazonStorage.isAmazonAccountLoggedIn()) {
                    return this._super();
                }

                if (!customer.isLoggedIn()) {
                    if (!(amazonStorage.isAmazonShippingAddressSelected() && this.validateGuestEmail())) {
						/*
						 Quick Fix (08/06/2021)
						 Hide below message
						 "No shipping address has been selected for this order..."
						*/
						//amazonMessages.addMessage('error', this.noShippingAddressSelectedMsg);
						//amazonMessages.displayMessages();

                        return false;
                    }
                }

                if (!(amazonStorage.isAmazonShippingAddressSelected())) {
					/*
					 Quick Fix (08/06/2021)
					 Hide below message
					 "No shipping address has been selected for this order..."
					*/
					//amazonMessages.addMessage('error', this.noShippingAddressSelectedMsg);
                    //amazonMessages.displayMessages();

                    return false;
                }

                return true;
            }
        });
    }
);
