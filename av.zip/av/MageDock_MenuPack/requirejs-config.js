var config = {
	config: {
        mixins: {
            'MageDock_MenuPack/js/md-menupack': {
                'MageDock_MenuPack/js/md-menupack-mixin': false
            },
        }
    }
};