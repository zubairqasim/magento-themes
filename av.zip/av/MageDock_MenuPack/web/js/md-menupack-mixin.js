define([
    'jquery',
    'jquery/ui'
], function ($) {
    'use strict';

    return function (widget) {
		var self,
			html = 'html',
			hc = '.page-header';
		
		$.widget('md.menupack', widget, {
			options: {
				menuItemBack: null,
				subMenuTitle: null,
				navSection: '.nav-sections'
			},
			_create: function () {
				self = this;
				self._super();
				console.info('md.menupack mixin create +++');
				if (self.options.selector != null) {
					self.options.menuItemBack = '.'+self.options.selector+'-menu-clone .mp-back';
					self.options.subMenuTitle = '.'+self.options.selector+'-title';
					self.options.mobileLinks = '.mobile-links';
					
					self._menuItemBack();
					self._subMenuTitle();
					
					$(window).bind('resize '+self.options.navSection, function(){
						$(self.options.navSection).width($(window).width());
					}).resize();
				}
			},
			_hoverMenuItem: function() {
				self = this;
				$(self.options.menuItem).on('mouseenter', function() {
					$(this).addClass('--opened');
					$(hc).addClass('--hover');
					//console.info('hover -- ' + ' add ' +  $(hc).length);
				});
				$(self.options.menuItem).on('mouseleave', function() {
					$(this).removeClass('--opened');
					$(hc).removeClass('--hover');
					//console.info('out -- ' + ' remove ' +  $(hc).length);
				});
			},
			_toggleMenuItem: function (form) {
				self = this;
				//console.info('md.menupack mixin _toggleMenuItem');
				$(self.options.menuItemAction).on('click', function(e) {
					e.preventDefault();
					e.stopPropagation();
					if(!$(this).parent().hasClass('--opened')) {
						//console.info('opened');
						$(html).addClass('navsub-open');
						//$(this).parent().addClass('--opened').siblings().removeClass('--opened');
						$(this).next().show().parent().addClass('--opened').siblings().removeClass('--opened').children(self.options.subMenu).hide();
						
						self._menuHeightReset();
						
					} else {
						//console.info('closed');
						$(html).removeClass('navsub-open');
						//$(this).parent().removeClass('--opened');
						$(this).next().hide().parent().removeClass('--opened');
					}
				});
			},
			_triggerMainMenu: function () {
				var slideMainMenu = this._slideMainMenu;
				this._action = {
					menuAction: $('[data-action="toggle-nav"]'),
					navSwipe: $('.nav-sections')
				};
				
				this._action.menuAction.off('click');
				this._action.menuAction.on('click', slideMainMenu.bind(this));
				//this._action.navSwipe.off('swipeleft');
				//this._action.navSwipe.on('swipeleft', slideMainMenu.bind(this));
			},
			_clearMenuSelection: function() {
				self = this;
				self._super();
				$(self.options.subMenuTitle).removeClass('opened');
				$('[data-selector="'+self.options.selector+'"],'+self.options.mobileLinks).attr('style','');
				$(html).removeClass('navsub-open');
			},
			_slideMainMenu: function () {
				var html = $('html');
				console.log('nav open mixin');
				if (html.hasClass('nav-open')) {
					html.removeClass('nav-open');
					//$(self.options.navSection).attr('style','');
					setTimeout(function () {
						html.removeClass('nav-before-open');
					}, this.options.hideDelay);
				} else {
					html.addClass('nav-before-open');
					$(self.options.navSection).css({'margin-top':$('.page-header').height(),'height':'calc(100% - '+$('.page-header').height()+'px)'});
					console.log($('.page-header').height());
					setTimeout(function () {
						html.addClass('nav-open');
					}, this.options.showDelay);
				}
				self._clearMenuSelection();
			},
			_menuItemBack: function() {
				self = this;
				$(self.options.menuItemBack).on('click', function(e) {
					self._clearMenuSelection();
				});
			},
			_subMenuTitle: function() {
				self = this;
				$(self.options.subMenuTitle).on('click', function(e) {
					$(this).toggleClass('opened');
					self._menuHeightReset();
				});
			},
			_menuHeightReset: function() {
				self = this;
				$('[data-selector="'+self.options.selector+'"]').height($(self.options.menuItem+'.--opened').find(self.options.subMenu).height());
			}
		});

		return $.md.menupack;
	}
});