/**
 * MageDock
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the MageDock.com license that is
 * available through the world-wide-web at this URL:
 * https://www.magedock.com/license-agreement
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @author    	MageDock Team
 * @package     MageDock_MenuPack
 * @copyright   Copyright (c) 2020 MageDock (https://www.magedock.com)
 * @license     https://www.magedock.com/license-agreement
 */

define([
    'jquery',
	'matchMedia',
    'jquery/ui'
], function($, mediaCheck) {
	'use strict';

	var self,
		currentUrl = window.location.href,
		body = 'body',
		html = 'html',
		main = '.page-main',
		hc = '.page-header',
		header = '.page-header',
		footer = '.page-footer',
		navigation = '.nav-sections',
		stickyPlaceholder = '.mp-sticky-placeholder',
		stickyHeight = 0,
		setTimer = null,
		pageScroll,
		scrollTop;
	
	$.widget('md.menupack', {
		options: {
			selector: null,
			responsive: true,
			desktop: true,
			showDelay: 42,
            hideDelay: 350,
			mediaBreakpoint: '(max-width: 1024px)',
			sticky: 'none',
			desktopEffect: 'none',
			mobileEffect: 'none',
			menuItemBack: null,
			subMenuTitle: null,
			navSection: '.nav-sections'
        },
		
        _create: function () {
            self = this;
			console.info('md.menupack create +++');
			if (self.options.selector != null) {
				self.options.menuWrap = '.'+self.options.selector+'-navigation';
				self.options.menuItem = '.'+self.options.selector+'-menu';
				self.options.menuItemAction = self.options.menuItem+'.--parent > a';
				self.options.subMenu = '.'+self.options.selector+'-submenu';
				self.options.subMenuWrap = self.options.subMenu+'-wrap';
				self.options.menuItemBack = '.'+self.options.selector+'-menu-clone .mp-back';
				self.options.subMenuTitle = '.'+self.options.selector+'-title';
				self.options.mobileLinks = '.mobile-links';
				
				self._menuItemBack();
				self._subMenuTitle();
				
				$(window).bind('resize '+self.options.navSection, function(){
					$(self.options.navSection).width($(window).width());
				}).resize();
				
				if(self.options.sticky != 'none') {
					$(body).addClass('mp-sticky');
					$(header).before('<div class="mp-sticky-placeholder">&nbsp;</div>');
					$(window).bind('scroll', self._stickyMainMenu);
					if($(window).scrollTop() > 0) {
						$(window).scroll();
					}
				}
			}
        },
		
        _init: function () {
			if (self.options.selector != null) {
				console.info('md.menupack init +++');
				$(self.options.menuWrap).menu();
				$(window).bind('resize '+ self.options.menuWrap, self.options, self._initMainMenu);
				
				mediaCheck({
					media: self.options.mediaBreakpoint,
					entry: $.proxy(function () {
						self.options.desktop = false;
						//console.warn('m ' + self.options.mobile + ' d: ' + self.options.desktop);
						$(self.options.subMenu+','+self.options.subMenuWrap).attr('style','');
						//self._initMainMenu();
						self._deviceMainMenu();
					}, self),
					exit: $.proxy(function () {
						setTimeout(function() {
							self.options.desktop = true;
							//console.warn('d ' + self.options.desktop + ' m: ' + self.options.mobile);
							$(self.options.subMenu+','+self.options.subMenuWrap).attr('style','');
							self._initMainMenu();
							self._webMainMenu();
						},350);
					}, self)
				});
				
				self._triggerMainMenu();
				self._activeMenuItem();
			}
		},
		
		_initMainMenu: function (opts) {
			
			if(self.options.desktop != true) {
				return false;
			}
			
			if(typeof opts != 'undefined') {
				self.options = opts.data;
			}
			
			var menuWrapWidth = $(self.options.menuWrap).width(),
				menuItemWidth, menuItemLeft, menuItemPosition,
				subMenu, subMenuLeft, subMenuRight, subMenuWidth;
			
			$(self.options.menuItem).each(function() {
				subMenu = $(this).find(self.options.subMenu);
				
				if(subMenu.length) {
					menuItemWidth = $(this).width();
					menuItemLeft = $(this).position().left;
					menuItemPosition = subMenu.attr('data-position');
					subMenuWidth = subMenu.attr('data-width') * menuWrapWidth / 100;
					subMenuLeft = menuWrapWidth - subMenuWidth;
					subMenuRight = 'auto';
					
					$(this).addClass('--'+menuItemPosition);

					////console.info(menuWrapWidth + ' ** ' +subMenuLeft + ' -- ' +subMenuWidth + ' ++ '+ menuItemLeft);
					//alert(menuItemLeft + '  <=   '+ subMenuLeft);
					
					if(menuItemPosition.indexOf('left-menu') !== -1) {
						subMenuLeft = 0;
					} else if(menuItemPosition.indexOf('right-menu') !== -1) {
						subMenuLeft = 'auto';
						subMenuRight = 0;
					} else if(menuItemPosition.indexOf('left-item') !== -1) {
						if(menuItemLeft <= subMenuLeft && subMenuLeft > 0) {
							subMenuLeft = menuItemLeft;
						}
					} else if(menuItemPosition.indexOf('right-item') !== -1) {
						menuItemLeft = menuItemLeft + menuItemWidth; 
						////console.info('mainmenu width: ' + menuWrapWidth + ' ====== submenu width:  ' +subMenuWidth + ' ======menu item position left: ' +menuItemLeft + ' ======submenu position left: '+ subMenuLeft + ' ======menu item id: ' + $(this).attr('id'));
						
						if(menuItemLeft >= subMenuWidth) {
							subMenuLeft = menuItemLeft - subMenuWidth;
						} else if(menuItemLeft <= subMenuWidth) {
							subMenuLeft = 0;
						}
					}
					
					subMenu.css({
						width: subMenuWidth,
						left: subMenuLeft,
						right: subMenuRight
					});
				}
			});
			
			self._clearMenuSelection();
		},
		
		_clearMenuSelection: function() {
			self = this;
			$(self.options.menuItem).removeClass('--opened');
			$(self.options.subMenuTitle).removeClass('opened');
			$('[data-selector="'+self.options.selector+'"],'+self.options.mobileLinks).attr('style','');
			$(html).removeClass('navsub-open');
		},
		
		_webMainMenu: function() {
			$(self.options.menuItemAction).off('click');
			self._hoverMenuItem();
		},
		
		_hoverMenuItem: function() {
			self = this;
			$(self.options.menuItem).on('mouseenter', function() {
				$(this).addClass('--opened');
				$(hc).addClass('--hover');
				//console.info('hover -- ' + ' add ' +  $(hc).length);
			});
			$(self.options.menuItem).on('mouseleave', function() {
				$(this).removeClass('--opened');
				$(hc).removeClass('--hover');
				//console.info('out -- ' + ' remove ' +  $(hc).length);
			});
		},
		
		_deviceMainMenu: function() {
			$(self.options.menuItem).off('mouseenter mouseleave');
			self._toggleMenuItem();
		},
		
		_toggleMenuItem: function() {
			self = this;
			//console.info('md.menupack _toggleMenuItem');
			$(self.options.menuItemAction).on('click', function(e) {
				e.preventDefault();
				e.stopPropagation();
				if(!$(this).parent().hasClass('--opened')) {
					//console.info('opened');
					$(html).addClass('navsub-open');
					//$(this).parent().addClass('--opened').siblings().removeClass('--opened');
					$(this).next().show().parent().addClass('--opened').siblings().removeClass('--opened').children(self.options.subMenu).hide();
					
					self._menuHeightReset();
					
				} else {
					//console.info('closed');
					$(html).removeClass('navsub-open');
					//$(this).parent().removeClass('--opened');
					$(this).next().hide().parent().removeClass('--opened');
				}
			});
		},
		
        _triggerMainMenu: function () {
			var slideMainMenu = this._slideMainMenu;
			this._action = {
				menuAction: $('[data-action="toggle-nav"]'),
				navSwipe: $('.nav-sections')
			};
			
			this._action.menuAction.off('click');
			this._action.menuAction.on('click', slideMainMenu.bind(this));
			//this._action.navSwipe.off('swipeleft');
			//this._action.navSwipe.on('swipeleft', slideMainMenu.bind(this));
        },

        _slideMainMenu: function () {
            var html = $('html');
			//console.log('nav open');
			if (html.hasClass('nav-open')) {
				html.removeClass('nav-open');
				//$(self.options.navSection).attr('style','');
				setTimeout(function () {
					html.removeClass('nav-before-open');
				}, this.options.hideDelay);
			} else {
				html.addClass('nav-before-open');
				$(self.options.navSection).css({'margin-top':$('.page-header').height(),'height':'calc(100% - '+$('.page-header').height()+'px)'});
				//console.log($('.page-header').height());
				setTimeout(function () {
					html.addClass('nav-open');
				}, this.options.showDelay);
			}
			self._clearMenuSelection();
        },
		
		_stickyMainMenu: function() {
			pageScroll = $(this).scrollTop();
			scrollTop = $(header).next().offset().top;
			
			if(self.options.sticky == 'menu') {
				stickyHeight = $(navigation).height();
			} else if(self.options.sticky == 'header') {
				stickyHeight = $(header).height();
			}
			
			//console.warn(scrollTop + '++');

			if( pageScroll > scrollTop ) {
				//console.warn('mp if--');
				$(body).addClass('mp-sticky-'+self.options.sticky);
				$(stickyPlaceholder).css({'display': 'block', 'height': stickyHeight});
				setTimer = setTimeout(function() {
					$(body).addClass('ready');
				},self.options.showDelay);
			} else {
				//console.warn('mp else++');
				$(body).removeClass('mp-sticky-'+self.options.sticky+' ready');
				$(stickyPlaceholder).attr('style','');
				if (setTimer) {
					clearTimeout(setTimer);
					setTimer = null;
				}
			}
		},
		
		_trimCurrentUrl: function() {
			if(currentUrl.indexOf('?')) {
				return currentUrl.split('?')[0];
			} else if(currentUrl.indexOf('#')) {
				return currentUrl.split('#')[0];
			} else {
				return currentUrl;
			}
		},
		
		_activeMenuItem: function() {
			$(self.options.menuItem).each(function() {
				if($(this).children('a').attr('href') == self._trimCurrentUrl()) {
					$(this).addClass('--active');
				}
			});
		},
		
		_menuItemBack: function() {
			self = this;
			$(self.options.menuItemBack).on('click', function(e) {
				self._clearMenuSelection();
			});
		},
		
		_subMenuTitle: function() {
			self = this;
			$(self.options.subMenuTitle).on('click', function(e) {
				$(this).toggleClass('opened');
				self._menuHeightReset();
			});
		},
		
		_menuHeightReset: function() {
			self = this;
			$('[data-selector="'+self.options.selector+'"]').height($(self.options.menuItem+'.--opened').find(self.options.subMenu).height());
		}
	});
 
    return $.md.menupack;
});