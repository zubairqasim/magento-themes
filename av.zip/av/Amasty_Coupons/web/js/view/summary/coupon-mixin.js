define([
    'Magento_Checkout/js/model/totals',
    'jquery'
], function (
    totals,
    $
) {
    'use strict';

    var mixin = {
        getCoupons: function () {
            var segment = totals.getSegment('amasty_coupon_amount');
            if (!segment) {
                return [];
            }

            //Magento 2.1.9 <= value type
            if ($.type(segment.value[0]) !== 'undefined' && $.type(segment.value[0]) === 'string') {
                //removing p2p coupons from the applied coupons
                if( window.hideP2PCoupons == 1 && window.p2pCodes != 0){
                    segment.value = $.map(segment.value, function(value) {
                        if( window.p2pCodes.indexOf(JSON.parse(value).coupon_code.toLowerCase().trim()) === -1){
                            return JSON.parse(value);
                        }
                    });
                } else {
                    segment.value = $.map(segment.value, function(value) {
                        return JSON.parse(value);
                    });
                }
            }

            return segment.value;
        }
    };

    return function (target) {
        return target.extend(mixin);
    };
});
