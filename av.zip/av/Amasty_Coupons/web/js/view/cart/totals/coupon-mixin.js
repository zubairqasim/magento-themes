define([
    'jquery'
], function (
    $
) {
    'use strict';

    var mixin = {
        getCoupons: function () {
            if(
                this.amount.length > 0 &&
                window.hideP2PCoupons == 1 &&
                window.p2pCodes != 0
            ){
                for(var i =0; i<= this.amount.length; i++){
                    if(this.amount[i]){
                        if(window.p2pCodes.indexOf(this.amount[i].coupon_code.toLowerCase().trim()) !== -1){
                            this.amount.splice(i,1);
                        }

                    }
                }
            }
          return this.amount;
        },
    };

    return function (target) {
        return target.extend(mixin);
    };
});
