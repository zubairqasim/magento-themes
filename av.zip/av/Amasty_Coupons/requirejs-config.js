var config = {
    config: {
        mixins: {
            'Amasty_Coupons/js/view/summary/coupon': {
                'Amasty_Coupons/js/view/summary/coupon-mixin': true
            },
            'Amasty_Coupons/js/view/cart/totals/coupon': {
                'Amasty_Coupons//js/view/cart/totals/coupon-mixin': true
            },
        }
    }
};
