/*jshint browser:true jquery:true*/
/*global alert*/
define(
    [
        'jquery',
        'ko',
        'uiComponent'
    ],
    function($, ko, Component) {
        'use strict';
        return Component.extend({
            listSelector: '#aw-storelocator-navigation',
            locationItems: {},
            selectedLocation: false,

            defaults: {
                template: 'Aheadworks_StoreLocator/location-list'
            },

            /**
             * Initializes model instance.
             */
            initialize: function () {
                this._super();
                this._initListConfig();
                this.listenDocumentClick();

                return this;
            },

            initObservable: function () {
                this._super()
                    .observe('selectedLocation');

                return this;
            },

            _initListConfig: function() {
                // set list items `active` property to false
                for (var i in this.locationItems) {
                    this.locationItems[i].active = false;
                }

                if (this.locationItems.length > 0) {
                    this.setSelectedLocation(this.locationItems[0]);
                }
            },

            setSelectedLocation: function(item, muteEvents) {
                this.selectedLocation(item);
                if (muteEvents !== true) this.trigger('selected', item);
            },

            listenDocumentClick: function () {
                var self = this;

                $(document).on("click", ".anchor-store-direction", function() {
                    var clickDirectionId = '';
                    var setItemDirection = '';
                    var clickDirectionUrl   = '';
                    var splitDirectionId = '';
                    clickDirectionId = $(this).attr('id');
                    clickDirectionUrl   = $(this).attr('rel');
                    splitDirectionId = clickDirectionId.split('-');
                    clickDirectionId = splitDirectionId[1];
                    if(clickDirectionUrl){
                        window.open(clickDirectionUrl, '_blank');
                    }else{
                        $(self.locationItems).each(function(i,itemObj) {
                            if(itemObj.location_id == clickDirectionId) {
                                setItemDirection = itemObj;
                                return false;
                            }
                        });

                        if(setItemDirection) {
                            var directionUrl = '';
                            directionUrl = self.getDirectionUrl(setItemDirection);
                            window.open(directionUrl, '_blank');
                        }
                    }
                });
            },
        });
    }
);
