/*jshint browser:true jquery:true*/
/*global alert*/
define(
    [
        'jquery',
        'ko',
        'uiComponent',
        'mage/template'
    ],
    function($, ko, Component, mageTemplate) {
        'use strict';
        return Component.extend({
            listSelector: '#aw-storelocator-navigation',
            locationItems: {},
            pagination: {},
            storeUrl: '',
            selectedLocation: false,

            defaults: {
                template: 'Aheadworks_StoreLocator/location-list'
            },

            /*
            starts,
            to implement ajax functionality,
            added other js work in this single file
            */
            latlngItems: [],
            markerItems: [],
            customMarkerIcons: [],
            infoWindowItems: [],
            mapPopup: '',
            initMapConfig: {
                latitude: 41.850033,
                longitude: -87.6500523,
                zoom: 3,
                selectedMarker: false
            },
            selectedMarker: false,
            mapSelector: "aw-storelocator-google-map",
            markers: [],
            clickPageUrl: null,
            requestInProcess: false,
            baseUrl: window.location.protocol + "//" + window.location.host,
            radiusPost: '',
            mediaUrl: '',
            markerClickIds: [],
            /*
            ends
            */

            /**
             * Initializes model instance.
             */
            initialize: function () {
                this._super();
                this._initListConfig();
                this.bindFormSubmit();
                this.listenDocumentClick();
                this.mediaUrl();

                return this;
            },

            mediaUrl: function () {
                if(window.storeMediaUrl != undefined) {
                    this.mediaUrl = window.storeMediaUrl;
                }
            },

            listenDocumentClick: function () {
                var self = this;
                $(document).on('click','.anchor-store-pagination', function(event) {
                    if($(this).attr('href')) {
                        event.stopPropagation();
                        event.preventDefault();
                        self.clickPageUrl = $(this).attr('href');
                        $('#aw-search-form').trigger('submit');
                    }
                });

                $(document).on("click", ".anchor-store-direction", function() {
                    var clickDirectionId = '';
                    var setItemDirection = '';
                    var clickDirectionUrl   = '';
                    var splitDirectionId = '';
                        clickDirectionId = $(this).attr('id');
                        clickDirectionUrl   = $(this).attr('rel');
                        splitDirectionId = clickDirectionId.split('-');
                        clickDirectionId = splitDirectionId[1];
                    if(clickDirectionUrl){
                            window.open(clickDirectionUrl, '_blank');
                    }else{
                        $(self.locationItems).each(function(i,itemObj) {
                            if(itemObj.location_id == clickDirectionId) {
                                setItemDirection = itemObj;
                                return false;
                            }
                        });

                        if(setItemDirection) {
                            var directionUrl = '';
                            directionUrl = self.getDirectionUrl(setItemDirection);
                            window.open(directionUrl, '_blank');
                        }
                    }
                });

                $(document).on("click", ".aw-storelocator-description", function() {
                    /*
                    $('#aw-storelocator-navigation').find('.aw-storelocator-navigation-item.active').each(function() {
                        $(this).removeClass('active');
                    });

                    $(this).parent('div').addClass('active');
                    */

                    var clickItemId = '';
                    var setItemLocation = '';
                    var splitItemId = '';
                        clickItemId = $(this).find('.aw-storelocator-navigation-item-title').attr('id');
                        //clickItemId = $(this).attr('id');
                        splitItemId = clickItemId.split('-');
                        clickItemId = splitItemId[1];

                    $(self.locationItems).each(function(i,itemObj) {
                        if(itemObj.location_id == clickItemId) {
                            setItemLocation = itemObj;
                            self._showMarkerResultAjax(setItemLocation, true);
                            return false;
                        }
                    });
                });
            },

            bindFormSubmit: function () {
                var self = this;

                $('#aw-search-form').on('submit', function(event) {
                    event.preventDefault();
                    var street = $.trim($('#street').val());
                      //new params
                      var radiusNew = $('#aw-storelocator-search-block-radius').val();
                      var phyFilter = $('#physician').val();
                      var retailFilter = $('#retail').val();
                    if(!street){ return }

                    event.stopPropagation();


                    //one ajax request at a time
                    if(self.requestInProcess == true) {
                        return false;
                    }
                    self.requestInProcess = true;

                    var ajaxUrl = '';
                    if(self.clickPageUrl != null) {
                        console.log('pagination url');
                        ajaxUrl = self.clickPageUrl;
                       // ajaxUrl = self.baseUrl+'/aw_store_locator/index/ajaxstores';
                    }
                    else {
                        console.log('normal url');
                        ajaxUrl = self.baseUrl+'/aw_store_locator/index/ajaxstores';
                    }


                    self.radius = $('#aw-storelocator-radius-select').val();
                    var measurement = $('#aw-storelocator-search-block-measurement').val();
                    self.loadingOverlay();
                    $.ajax({
                        method: "POST",
                        url: ajaxUrl,
                        dataType: "json",
                        data:jQuery('#aw-search-form').serialize(),
                        //data: { street: street, radius: self.radius, measurement: measurement, radiusNew: radiusNew, phyFilter:phyFilter, retailFilter:retailFilter }
                    })
                    .done(function(result) {
                        console.log( "success" );
                        //console.log(result);
                        self.locationItems = result.locationJson;
                        self.pagination = result.paginationJson;
                        self.initializeMap();

                        //renders pagination
                        $('#sidebar-pagination').html(self.pagination);

                        //renders right location details block
                        var html = mageTemplate('#test-world-template', {
                                        locationItems:self.locationItems,
                                        getStoreCount: self.getStoreCount()
                                    });

                        $('#aw-storelocator-navigation').html(html);
                    })
                    .fail(function(result) {
                        console.log( "error" );
                    })
                    .always(function(result) {
                        console.log( "complete" );
                        self.removeLoadingOverlay();
                        self.clickPageUrl = null;
                        self.requestInProcess = false;
                    });
                });
            },

            editClient: function (location_id) {
                alert('fffff '+location_id);
            },

            getStoreCount: function () {
                if(this.locationItems.length > 0) {
                    var streetVal = $('#street').val();
                    var htmlTotal = this.locationItems.length+' ';
                        htmlTotal += 'Results for ';
                        htmlTotal += streetVal;

                    var htmlTopTotal = '';
                        htmlTopTotal += this.locationItems.length+' ';
                        htmlTopTotal += 'Results';

                    $('#total-count').html('<span>'+htmlTopTotal+'</span>');

                    return htmlTotal;
                }
                return false;
            },

            getDirectionUrl: function (item) {
                var cleanStreet = item.street.replace(/[_\W]+/g, ' ');
                this.storeUrl = '';
                this.storeUrl += 'https://www.google.com/maps/dir//';
                this.storeUrl += $.trim(cleanStreet)+',';
                this.storeUrl += $.trim(item.zip)+',';
                this.storeUrl += $.trim(item.country)+',';
                this.storeUrl += '/@';
                this.storeUrl += $.trim(item.latitude)+',';
                this.storeUrl += $.trim(item.longitude);
                this.storeUrl = this.storeUrl.replace(/ /g, "+");

                return this.storeUrl;
            },

            initObservable: function () {
                this._super()
                    .observe('selectedLocation');

                return this;
            },

            _initListConfig: function() {
                // set list items `active` property to false
                for (var i in this.locationItems) {
                    this.locationItems[i].active = false;
                }
                if (this.locationItems.length > 0) {
                    //below line is generating error after ajax request
                    //this.setSelectedLocation(this.locationItems[0]);
                }
            },

            setSelectedLocation: function(item, muteEvents) {
                this.selectedLocation(item);
                if (muteEvents !== true) this.trigger('selected', item);
            },

            /**
             * Initializes model instance.
             */
            initializeMap: function () {
                this._initMapConfigAjax();
                this._initMapAjax();
            },

            /*
            starts,
            to implement ajax functionality,
            added other js work in this single file
            */
            _initMapConfigAjax: function () {
                if (undefined !== this.locationItems && this.locationItems.length > 0) {
                    var initialLocation = this.locationItems[0];
                    this.initMapConfig.zoom = parseInt(10); //the static zoom value, need to be used globally
                    this.initMapConfig.latitude = initialLocation.latitude;
                    this.initMapConfig.longitude = initialLocation.longitude;
                    this.initMapConfig.selectedMarker = initialLocation;
                }
                else {
                    //default US map
                    this.initMapConfig.zoom = parseInt(3);
                    this.initMapConfig.latitude = 41.850033;
                    this.initMapConfig.longitude = -87.6500523;

                    $('#total-count').html('<span>0 Results</span>');
                }
            },

            _initMapAjax: function () {
                var latlng = new google.maps.LatLng(this.initMapConfig.latitude, this.initMapConfig.longitude);

                if (undefined !== this.locationItems && this.locationItems.length > 0) {
                    var mapOptions = {
                        //zoom: this.initMapConfig.zoom,
                        zoom: this.radiusToZoomAjax(this.radius),
                        center: latlng,
                        mapTypeId: google.maps.MapTypeId.ROADMAP,
                        scrollwheel: false,
                        mapTypeControl: false,
                        styles: [
                              {
                                "elementType": "geometry",
                                "stylers": [
                                  {
                                    "color": "#f5f5f5"
                                  }
                                ]
                              },
                              {
                                "elementType": "labels.icon",
                                "stylers": [
                                  {
                                    "visibility": "off"
                                  }
                                ]
                              },
                              {
                                "elementType": "labels.text.fill",
                                "stylers": [
                                  {
                                    "color": "#616161"
                                  }
                                ]
                              },
                              {
                                "elementType": "labels.text.stroke",
                                "stylers": [
                                  {
                                    "color": "#f5f5f5"
                                  }
                                ]
                              },
                              {
                                "featureType": "administrative.land_parcel",
                                "elementType": "labels.text.fill",
                                "stylers": [
                                  {
                                    "color": "#bdbdbd"
                                  }
                                ]
                              },
                              {
                                "featureType": "poi",
                                "elementType": "geometry",
                                "stylers": [
                                  {
                                    "color": "#eeeeee"
                                  }
                                ]
                              },
                              {
                                "featureType": "poi",
                                "elementType": "labels.text.fill",
                                "stylers": [
                                  {
                                    "color": "#757575"
                                  }
                                ]
                              },
                              {
                                "featureType": "poi.park",
                                "elementType": "geometry",
                                "stylers": [
                                  {
                                    "color": "#e5e5e5"
                                  }
                                ]
                              },
                              {
                                "featureType": "poi.park",
                                "elementType": "labels.text.fill",
                                "stylers": [
                                  {
                                    "color": "#9e9e9e"
                                  }
                                ]
                              },
                              {
                                "featureType": "road",
                                "elementType": "geometry",
                                "stylers": [
                                  {
                                    "color": "#ffffff"
                                  }
                                ]
                              },
                              {
                                "featureType": "road.arterial",
                                "elementType": "labels.text.fill",
                                "stylers": [
                                  {
                                    "color": "#757575"
                                  }
                                ]
                              },
                              {
                                "featureType": "road.highway",
                                "elementType": "geometry",
                                "stylers": [
                                  {
                                    "color": "#dadada"
                                  }
                                ]
                              },
                              {
                                "featureType": "road.highway",
                                "elementType": "labels.text.fill",
                                "stylers": [
                                  {
                                    "color": "#616161"
                                  }
                                ]
                              },
                              {
                                "featureType": "road.local",
                                "elementType": "labels.text.fill",
                                "stylers": [
                                  {
                                    "color": "#9e9e9e"
                                  }
                                ]
                              },
                              {
                                "featureType": "transit.line",
                                "elementType": "geometry",
                                "stylers": [
                                  {
                                    "color": "#e5e5e5"
                                  }
                                ]
                              },
                              {
                                "featureType": "transit.station",
                                "elementType": "geometry",
                                "stylers": [
                                  {
                                    "color": "#eeeeee"
                                  }
                                ]
                              },
                              {
                                "featureType": "water",
                                "elementType": "geometry",
                                "stylers": [
                                  {
                                    "color": "#c9c9c9"
                                  }
                                ]
                              },
                              {
                                "featureType": "water",
                                "elementType": "labels.text.fill",
                                "stylers": [
                                  {
                                    "color": "#9e9e9e"
                                  }
                                ]
                              }
                            ]
                    };
                }
                else {
                    var mapOptions = {
                        zoom: this.initMapConfig.zoom,
                        center: latlng,
                        mapTypeId: google.maps.MapTypeId.ROADMAP,
                        scrollwheel: false,
                        mapTypeControl: false,
                        styles: [
                              {
                                "elementType": "geometry",
                                "stylers": [
                                  {
                                    "color": "#f5f5f5"
                                  }
                                ]
                              },
                              {
                                "elementType": "labels.icon",
                                "stylers": [
                                  {
                                    "visibility": "off"
                                  }
                                ]
                              },
                              {
                                "elementType": "labels.text.fill",
                                "stylers": [
                                  {
                                    "color": "#616161"
                                  }
                                ]
                              },
                              {
                                "elementType": "labels.text.stroke",
                                "stylers": [
                                  {
                                    "color": "#f5f5f5"
                                  }
                                ]
                              },
                              {
                                "featureType": "administrative.land_parcel",
                                "elementType": "labels.text.fill",
                                "stylers": [
                                  {
                                    "color": "#bdbdbd"
                                  }
                                ]
                              },
                              {
                                "featureType": "poi",
                                "elementType": "geometry",
                                "stylers": [
                                  {
                                    "color": "#eeeeee"
                                  }
                                ]
                              },
                              {
                                "featureType": "poi",
                                "elementType": "labels.text.fill",
                                "stylers": [
                                  {
                                    "color": "#757575"
                                  }
                                ]
                              },
                              {
                                "featureType": "poi.park",
                                "elementType": "geometry",
                                "stylers": [
                                  {
                                    "color": "#e5e5e5"
                                  }
                                ]
                              },
                              {
                                "featureType": "poi.park",
                                "elementType": "labels.text.fill",
                                "stylers": [
                                  {
                                    "color": "#9e9e9e"
                                  }
                                ]
                              },
                              {
                                "featureType": "road",
                                "elementType": "geometry",
                                "stylers": [
                                  {
                                    "color": "#ffffff"
                                  }
                                ]
                              },
                              {
                                "featureType": "road.arterial",
                                "elementType": "labels.text.fill",
                                "stylers": [
                                  {
                                    "color": "#757575"
                                  }
                                ]
                              },
                              {
                                "featureType": "road.highway",
                                "elementType": "geometry",
                                "stylers": [
                                  {
                                    "color": "#dadada"
                                  }
                                ]
                              },
                              {
                                "featureType": "road.highway",
                                "elementType": "labels.text.fill",
                                "stylers": [
                                  {
                                    "color": "#616161"
                                  }
                                ]
                              },
                              {
                                "featureType": "road.local",
                                "elementType": "labels.text.fill",
                                "stylers": [
                                  {
                                    "color": "#9e9e9e"
                                  }
                                ]
                              },
                              {
                                "featureType": "transit.line",
                                "elementType": "geometry",
                                "stylers": [
                                  {
                                    "color": "#e5e5e5"
                                  }
                                ]
                              },
                              {
                                "featureType": "transit.station",
                                "elementType": "geometry",
                                "stylers": [
                                  {
                                    "color": "#eeeeee"
                                  }
                                ]
                              },
                              {
                                "featureType": "water",
                                "elementType": "geometry",
                                "stylers": [
                                  {
                                    "color": "#c9c9c9"
                                  }
                                ]
                              },
                              {
                                "featureType": "water",
                                "elementType": "labels.text.fill",
                                "stylers": [
                                  {
                                    "color": "#9e9e9e"
                                  }
                                ]
                              }
                            ]
                    };
                }

                this.map = new google.maps.Map(document.getElementById(this.mapSelector), mapOptions);

                if (this.initMapConfig.selectedMarker) {
                    for (var i = 0; i < this.locationItems.length; i++) {
                        this._showMarkerAjax(this.locationItems[i]);
                    }

                    //below line generating error in console
                    //this.setSelectedMarker(this.initMapConfig.selectedMarker);
                }
            },

            setSelectedMarkerAjax: function(item, muteEvents) {
                this.selectedMarker = item;
                this.panToAjax(item);
                if (!muteEvents) {
                    //below line generating error in console
                    //this.trigger('selected', this.selectedMarker);
                }
            },

            _addLatLngItemAjax: function(item) {
                return this.latlngItems[item.location_id] = new google.maps.LatLng(item.latitude, item.longitude);
            },

            _addMarkerItemAjax: function(item, config) {
                return this.markerItems[item.location_id] = new google.maps.Marker(config);
            },

            _addCustomMarkerIconAjax: function(item) {
                return this.customMarkerIcons[item.location_id] = {
                    url: item.custom_marker,
                    size: new google.maps.Size(20, 32),
                    scaledSize: new google.maps.Size(20, 32)
                };
            },

            _addInfoWindowItemAjax: function(item) {
                return this.infoWindowItems[item.location_id] = new google.maps.InfoWindow({
                    content: (mageTemplate(this.infoWindowTemplateAjax(item), {
                        data: item
                    })),
                    identity: item.location_id,
                    maxWidth: 530
                });
            },

            panToAjax: function (item) {
                this.map.panTo(this.latlngItems[item.location_id]);
                //this.map.setZoom(parseInt(item.zoom));
                //this.map.setZoom(13); //important, we need to focus on radius with zoom
            },

            /*
            Below method perfectly work for marker position and window pop,
            if click on marker image,
            not work if click on result item
            */
            _showMarkerAjax: function (locationItem) {
                var latlng = this._addLatLngItemAjax(locationItem);

                if(this.mediaUrl) {
                    var markerConfig = {
                        position: latlng,
                        map: this.map,
                        icon: this.mediaUrl+'aheadworks/map-pointer.png',
                    };
                }
                else {
                    var markerConfig = {
                        position: latlng,
                        map: this.map,
                    };
                }

                if (locationItem.custom_marker) {
                    var icon = this._addCustomMarkerIconAjax(locationItem);
                    markerConfig.icon = icon;
                }
                var marker = this._addMarkerItemAjax(locationItem, markerConfig);
                this.markers[locationItem.location_id] = marker;
                var infoWindow = this._addInfoWindowItemAjax(locationItem);

                var self = this;
                google.maps.event.addListener(marker, 'click', function () {
                    /*
                    custom work,
                    icon change on click
                    */
                    self.markerClickIds.push(locationItem.location_id);
                    self.resetMarkerIcons();
                    self.markers[locationItem.location_id].setIcon(self.mediaUrl+'aheadworks/selected-map-pointer.png');
                    /*
                    ends
                    */
                    self.infoWindowItems.each(function (w) {
                        w.close();
                    });

                    /*
                    custom work,
                    set active class on right scroll box
                    */
                    $('#aw-storelocator-navigation').find('.aw-storelocator-navigation-item.active').each(function() {
                        $(this).removeClass('active');
                    });

                    $('#item-'+locationItem.location_id).parent().parent('div').addClass('active');
                    /*
                    ends
                    */

                    infoWindow.open(self.map, self.markerItems[locationItem.location_id]);
                    self.setSelectedMarkerAjax(locationItem);
                });
            },

            resetMarkerIcons: function () {
                for (var i = 0; i < this.markerClickIds.length; i++) {
                    this.markers[this.markerClickIds[i]].setIcon(this.mediaUrl+'aheadworks/map-pointer.png');
                    //this.markerClickIds.splice($.inArray(this.markerClickIds[i], this.markerClickIds),1);
                }
            },

            /*
            Below method perfectly work for window pop only,
            if click on result item
            */
            _showMarkerResultAjax: function (locationItem) {
                google.maps.event.trigger(this.markers[locationItem.location_id], 'click');
                /*
                var latlng = this._addLatLngItemAjax(locationItem);
                var markerConfig = {
                    position: latlng,
                    map: this.map
                };

                this.infoWindowItems.each(function (w) {
                    w.close();
                });

                var infoWindow = this._addInfoWindowItemAjax(locationItem);
                infoWindow.open(this.map, this.markerItems[locationItem.location_id]);
                this.setSelectedMarkerAjax(locationItem);
                */
                //console.log(locationItem.toString()+'===showMarker==='+locationItem.toSource());
                /*
                var infoWindow = this._addInfoWindowItemAjax(locationItem);
                var self = this;

                self.infoWindowItems.each(function (w) {
                    w.close();
                });

                infoWindow.open(self.map, self.markerItems[locationItem.location_id]);
                self.setSelectedMarkerAjax(locationItem);
                */
            },

            radiusToZoomAjax: function(radius) {
                return Math.round(14-Math.log(radius)/Math.LN2);
            },

            infoWindowTemplateAjax: function (item) {
                var cleanStreet = item.street.replace(/[_\W]+/g, ' ');
                var storeUrl = '';
                storeUrl += 'https://www.google.com/maps/dir//';
                storeUrl += $.trim(cleanStreet)+',';
                storeUrl += $.trim(item.zip)+',';
                storeUrl += $.trim(item.country)+',';
                storeUrl += '/@';
                storeUrl += $.trim(item.latitude)+',';
                storeUrl += $.trim(item.longitude);
                storeUrl = storeUrl.replace(/ /g, "+");

                var pImageUrl   = "",
                    pDirection  = "",
                    pEmail      = "",
                    pWebsite    = "",
                    pfbURL      = "",
                    pinstURL    = "",
                    ptwtURL     = "",
                    pLnumber    = "",
                    pStreet     = "",
                    pCity       = "",
                    pState      = "",
                    pZip        = "",
                    pTelnumber  = "",
                    pHours      = "",
                    pWebsite    = "",
                    pNumber     = "",
                    Pintro      = "",
                    pFacebook   = "",
                    pInstagram  = "",
                    pTwitter    = "",
                    pDetail     = "",
                    p1Email     = "",
                    p1Number    = "",
                    directionURL= "",
                    apiKey      = "",
                    pDetailUrl  = "";


                if(typeof item !== 'undefined') {

                    if(typeof item.direction_url !== 'undefined')
                    {
                        //alert(item.direction_url);
                        if(item.direction_url){
                        directionURL = item.direction_url;
                        }else
                        {
                        directionURL =  storeUrl;
                        }

                    }

                    if(typeof item.profile_image !== 'undefined'){
                        pImageUrl   = item.profile_image;
                    }
                    else if(typeof item.photo_ref !== 'undefined'){

                        if(item.photo_ref) {
                        pImageUrl   = item.photo_ref;
                        apiKey      = item.api_key;
    pImageUrl   = "https://maps.googleapis.com/maps/api/place/photo?maxwidth=600&photoreference="+pImageUrl+"&key="+apiKey;
                        }else
                        {
                            pImageUrl = "/media/aheadworks/placeholder-salon.jpg";
                        }
                    }else{
                        pImageUrl = "/media/aheadworks/placeholder-small-salon.jpg";
                    }

                    if(typeof item.email !== 'undefined' && item.email!=null){
                        if(item.email){
                        pEmail  = "<p><span>Email:</span> "+item.email+"</p>";
                        }
                    }
                    if(typeof item.email !== 'undefined' && item.email!=null){
                        if(item.email){
                        p1Email = item.email;
                        }
                    }

                    if(typeof item.phy_facebook_link !== 'undefined'){
                        pfbURL  = item.phy_facebook_link;
                    }
                    if(typeof item.phy_instagram_link !== 'undefined'){
                        pinstURL    = item.phy_instagram_link;
                    }
                    if(typeof item.phy_twitter_link !== 'undefined'){
                        ptwtURL = item.phy_twitter_link;
                    }
                    if(typeof item.city !== 'undefined'){
                        pCity   = item.city;
                    }
                    if(typeof item.region_code !== 'undefined'){
                        pState  = item.region_code;
                    }
                    if(typeof item.zip !== 'undefined'){
                        pZip    = item.zip;
                    }
                    if(typeof item.license_number !== 'undefined'){
                        pLnumber    = "<p><span>License Number:</span> "+item.license_number+"</p>";
                    }
                    if(typeof item.street !== 'undefined'){
                        pStreet = "<p><span>Address:</span> "+item.street+", "+pCity+" "+pState+" "+pZip+"<br /></p>";
                    }
                    if(typeof item.phone !== 'undefined' && item.phone!='NULL'){
                        if(item.phone){
                        pTelnumber  = "<p><span>Phone/Call:</span> "+item.phone+"</p>";
                        }
                    }
                    if(typeof item.hours !== 'undefined' && item.hours!=null ){
                        pHours  = "<p><span>Hours:</span> <a href='#' class='button-link1 action-hours'>Opening Hours</a></p>";
                        var pDays = item.hours.split(',');
                        pHours += '<p class="hours">';
                        for(var x=0; x < pDays.length; x++) {
                            pHours +='<span>'+pDays[x].replace(/u/g, "").replace(/\\/g, '').replace(/#|_|\[|\]|\"/g,'').replace(/2013/g,'-')+'</span>';
                        }
                        pHours += '</p>';
                    }
                    if(typeof item.website !== 'undefined' && item.website!=null){
                        pWebsite    = item.website;
                    }
                    if(typeof item.phone !== 'undefined' && item.phone!='NULL'){
                        if(item.phone){
                        pNumber = item.phone;
                        }
                    }
                    if(typeof item.phone !== 'undefined' && item.phone!='NULL'){
                        if(item.phone){
                        p1Number    = item.phone;
                        }
                    }

                    var pReadmoreUrl= "";
                    pReadmoreUrl    = "/store-locator?store=" + item.location_id
                                + "&token=see-detail";

                    if(typeof item.practice_introduction !== 'undefined'){

                        var Pintro = item.practice_introduction;
                        if(Pintro){
                            var strPintro = Pintro;
                            if(strPintro.length>180){
                               strPintro = strPintro.substr(0,180)+'...';
                               strPintro += '<a href='+pReadmoreUrl+' target="_blank">Read More</a>'; //target area you need to place read more link
                            }
                            Pintro = '<p><span>Practice Introduction:</span> '+strPintro+'</p>';
                        }
                        //alert(Pintro);
                        //Pintro    = "<strong>Practice Introduction : </strong>"+item.practice_introduction+"<br>";
                    }

                    pFacebook   = this.mediaUrl + "wysiwyg/glytone/fb-icon.jpg",
                    pInstagram  = this.mediaUrl + "wysiwyg/glytone/insta-icon.jpg",
                    pTwitter    = this.mediaUrl + "wysiwyg/glytone/twitter-icon.jpg",
                    pDetail     = pLnumber
                                + pTelnumber
                                + pStreet
                                + pEmail
                                + pHours
                                + Pintro,

                    pDetailUrl  = "/store-locator?store=" + item.location_id
                                + "&token=see-detail";

                }

                var SocialLinks = "";

                    //console.log(pfbURL);
                    //console.log(pinstURL);
                    //console.log(ptwtURL);

                if(pfbURL || pinstURL || ptwtURL)
                {
                    var pFbOne      ="";
                    var pInsOne     ="";
                    var pTwtOne     ="";



                    if(pfbURL)   {  pFbOne = '<li><a class="facebook" href="'+pfbURL+'" target="_blank" title="Facebook"><span>Facebook</span></a></li>'; }
                    if(pinstURL) {  pInsOne = '<li><a class="instagram" href="'+pinstURL+'" target="_blank" title="Instagram"><span>Instagram</span></a></li>';}
                    if(ptwtURL)  {  pTwtOne = '<li><a class="twitter" href="'+ptwtURL+'" target="_blank" title="Twitter"><span>Twitter</span></a></li>';}

                    //console.log(pFbOne+"===");
                    //console.log(pInsOne+"===");
                    //console.log(pTwtOne+"===");

                    SocialLinks = '<ul class="social-links">>'
                                + pFbOne
                                + pInsOne
                                + pTwtOne
                    SocialLinks + '</ul>';
                }
                var LeftNav     = "";
                if(p1Number !="" || p1Email !="" || pWebsite !="")
                {
                    var leftOne     = "";
                    var leftTwo     = "";
                    var leftThree   = "";


                    if(p1Number)   {  leftOne   = '<a class="action primary" href="tel:'+p1Number+'">Phone/Call</a>'; }
                    if(p1Email)    {  leftTwo   = '<a class="action primary" href="mailto:'+p1Email+'">Email Doctor</a>'; }
                    if(pWebsite)   {  leftThree = '<a class="action primary" target="_blank" href="'+pWebsite+'">Visit Website</a>'; }



                    LeftNav     =   leftOne
                                +   leftTwo
                                +   leftThree;
                }

                    //alert(LeftNav);
                    //alert(p1Number);
                    //alert(p1Email);
                    //alert(pWebsite);


                    //<% if(data.distance) { %><%- data.distance %> miles<% } %></div>
                this.mapPopup   = '<div class ="aw-storelocator-template">'
                                +    '<div class="aw-storelocator-info-window">'
                                +       '<div class="dg-container popup">'
                                +           '<div class="dg-title">'
                                +               '<img src="'+pImageUrl+'" alt=""/>'
                                +               '<h2><%- data.title %></h2>'
                                +           '</div>'
                                +           '<div class="dg-content">'
                                +               '<div class="dg-sidebar">'
                                +                   '<div class="detail">'
                                +                       '<div class="actions">'
                                +                           '<a class="action primary" target="_blank" href="'+directionURL+'">Get Directions</a>'
                                +                           LeftNav
                                +                       '</div>'
                                +                       SocialLinks
                                +                   '</div>'
                                +               '</div>'
                                +               '<div class="dg-main">'
                                +                   '<div class="detail">'
                                +                       pDetail
                                +                       '<div class="actions">'
                                +                           '<a href="'+pDetailUrl+'" target="_blank" class="action secondary">See Details</a>'
                                +                       '</div>'
                                +                   '</div>'
                                +               '</div>'
                                +           '</div>'
                                +       '</div>'
                                +    '</div>'
                                +'</div>';

                return this.mapPopup;
            },
            /*
            ends
            */
            loadingOverlay: function () {
                var overlay = $('<div id="loading-mask2" class="loading-mask"><div class="background-overlay"></div><p id="loading_mask_loader2" class="loader"><br>Processing... Please wait...</p></div>');
                    overlay.appendTo(document.body);
            },

            removeLoadingOverlay: function () {
                $("#loading-mask2").remove();
            }
        });
    }
);
