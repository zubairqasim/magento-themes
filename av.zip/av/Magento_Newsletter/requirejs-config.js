var config = {
    map: {
        '*': {
            'cd_newsletter': 'Magento_Newsletter/js/cdNewsletter'
        }
    }
};
