define([
    'jquery',
    'pf_helper',
    "fancyboxjs",
    'jquery/validate'
], function($, helper){
    "use strict";
    var self = this;
    $.widget('cd.newsletter', {
        helper: helper({}),
        options: {
            action: null,
            location: null,
            formId: null,
            callbackUrl: null,
            p2p_user: 0,
            alreadySubscribed: false,
            requestCompleted: false,
            success: 0,
            thank_you_box: '#newsletter_thanyou',
            cookieExpDays: 1,
            cookieName: "pop-up-avene",
            formData: {},
            error: false,
            userRegistered: false
        },

        _create: function () {
            self = this;
            if(Object.keys(self.options.formData).length > 0){
                $(document).on('submit', 'form[data-role="newsletter"]', function(){
                    //if(self.options.requestCompleted === false){
                    $(self.options.formData[$(this).attr('data-location')].formId).find('.mage-error').html('');
                    $(self.options.formData[$(this).attr('data-location')].formId).find('.mage-error').hide();
                    self.subscribe(self.options.formData[$(this).attr('data-location')]);
                    //}
                });

                $(document).on('click', 'form[data-role="newsletter"] button[type="submit"]', function(){
                    if(self.isValid($(this).closest('form')) !== true){
                        $($(this).closest('form')).find('.mage-error').html('');
                        $($(this).closest('form').attr('id')).find('.mage-error').hide();
                    }
                });
            }

            /**
             * if successParam is success
             * shown the thank you popup
             */
            if(
                self.options.success === 1 &&
                self.helper.getCookie(self.options.cookieName) === false &&
                self.options.p2p_user === 0
            ) {
                self.helper.setCookie(self.options.cookieName, 1, self.options.cookieExpDays);
                $.fancybox.open($(self.options.thank_you_box));
            }
            this._super();
        },

        _init: function () {
            self = this;
            this._super();
        },
        
        //custom checkcaptcha on newsletter form
        checkCaptcha: function() {
            if ((jQuery('#g-recaptcha-response').val()) === '') {
                jQuery('#error-msg').css('display', 'block');
                jQuery('#error-msg').css('color', '#DF280A');
                jQuery('#error-msg').css('font-size', 13);
                return false;
            } else {
                jQuery('#error-msg').css('display', 'none');
                return true;
            }
        },
        
        subscribe: function(form){
            if(this.checkCaptcha() === false){
                return false;
            }
            self = this;
            $(form.formId).find('.mage-error').html('');
            $(form.formId).find('.mage-error').hide();
            $.ajax({
                url     : form.action,
                type    : "POST",
                dataType: "JSON",
                showLoader: true,
                data: $(form.formId).serialize()+'&location='+form.location+'&isAjax=1',
                success: function(response){
                    self.helper.setCookie("newsletter_email",$(form.formId).find('input[name="email"]').val(),20,"seconds");
                    if(response.error === false ){
                        self.options.alreadySubscribed = response.already_subscribed;
                        if( response.already_subscribed == true ) {
                            $(form.formId).find('.mage-error').html(response.message);
                            $(form.formId).find('.mage-error').show();

                            if($(form.formId).find('.mage-error').length > 1){
                                $(form.formId).find('#custom-msg').hide();
                            }
                        } else {
                            self.helper.setCookie(self.options.cookieName, false, 1, 'seconds');
                            window.dataLayer = window.dataLayer || [];
                            dataLayer.push(form.dataLayer);
                        }
                    } else if( response.error === true ) {
                        if(response.user_registered === true){
                            self.helper.setCookie(self.options.cookieName, false, 1, 'seconds');
                            self.options.userRegistered = response.user_registered;
                            window.dataLayer = window.dataLayer || [];
                            dataLayer.push(form.dataLayer);
                        }
                        self.options.error = true;
                    }
                },
                error: function(response){
                }
            }).always(function(){
                self.options.requestCompleted = true;
                if( self.options.alreadySubscribed == false || self.options.userRegistered === true){
                    window.location.href = self.options.callbackUrl
                    //$(form.formId)[0].submit();
                }
            });
        },

        isValid: function (form) {
            return form.valid();
        }
    });

    return $.cd.newsletter;
});
