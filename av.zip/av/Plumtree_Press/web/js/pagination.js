/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
/*jshint browser:true, jquery:true*/
/*global confirm:true*/
define([
    'jquery',
    'jquery/ui',
], function($){
    "use strict";

    $.widget('pf.press_pagination', {

        options: {
            in_the_press_pagination_element: null,
            video_reviews_pagination_element: null,
            social_gallery_pagination_element: null,
            online_mentions_pagination_element: null,
            in_the_press_tab_id: null,
            video_reviews_tab_id: null,
            social_gallery_tab_id: null,
            online_mentions_tab_id: null,
            pageUrl: null,
            requestInProcess: false
        },

        _create: function () {
            var self = this;
            this._super();
        },

        _init: function () {
            var self = this;
            if(
                self.options.in_the_press_tab_id != null &&
                self.options.video_reviews_tab_id != null &&
                self.options.social_gallery_tab_id != null
            ){
                if($(self.options.in_the_press_pagination_element).length > 0){
                    self.initializeAnchorClick(self.options.in_the_press_pagination_element, self.options.in_the_press_tab_id.substr(1));
                }

                if($(self.options.video_reviews_pagination_element).length > 0){
                    self.initializeAnchorClick(self.options.video_reviews_pagination_element, self.options.video_reviews_tab_id.substr(1));
                }

                if($(self.options.social_gallery_pagination_element).length > 0){
                    self.initializeAnchorClick(self.options.social_gallery_pagination_element, self.options.social_gallery_tab_id.substr(1));
                }

                if($(self.options.online_mentions_pagination_element).length > 0){
                    self.initializeAnchorClick(self.options.online_mentions_pagination_element, self.options.online_mentions_tab_id.substr(1));
                }
            }
            this._super();
        },

        /**
         * Prevent the default click event of toolbaar
         * anchors and embed the ajax
         *
         * @param string element
         * @param string tab
         *
         */
        initializeAnchorClick: function(element, tab){
            var self = this;
            $(document).on("click", element, function(event){
                if($(this).attr("href")){
                    event.stopPropagation();
                    event.preventDefault();
                    self.options.pageUrl = $(this).attr("href");
                    self.triggerPagination(tab);
                }
            });
        },

        /**
         * Perform ajax functionality
         *
         * @param string tab
         */
        triggerPagination: function(tab){
            var self = this;
            if( self.options.pageUrl != null && self.options.requestInProcess == false){

                //one ajax request at a time
                self.requestInProcess = true;
                var ajaxUrl = self.options.pageUrl;
                $.ajax({
                    url: ajaxUrl,
                    type: "GET",
                    dataType: "JSON",
                    data: { isAjax: true, tab:tab }
                }).done(function(response){
                    if(response.tab == "tab_social"){
                        $(self.options.social_gallery_tab_id).html(response.block);
                    }

                    if(response.tab == "tab_video"){
                        $(self.options.video_reviews_tab_id).html(response.block);
                    }

                    if(response.tab == "tab_online"){
                        $(self.options.online_mentions_tab_id).html(response.block);
                    }

                    if(response.tab == "tab_press"){
                        $(self.options.in_the_press_tab_id).html(response.block);
                    }

                    //scroll to the tab-container position
                    if( $(".tab-container").length > 0){
                        var top = $(".tab-container").offset().top;
                        top = top - 80;
                        $("html, body").animate({scrollTop: top}, "fast");
                    }
                }).fail(function(response){
                    //request gets failed
                }).always(function(response){
                    //perform functionality that needs to be triggered all the time
                });
            }

        }

    });
    return $.pf.press_pagination;
});
