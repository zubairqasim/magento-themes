var config = {
	map: {
        '*' : {
            'pf_sendfriend' : 'Magento_SendFriend/js/pf.sendfriend'
        }
    },
};