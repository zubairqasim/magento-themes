/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
/*jshint browser:true, jquery:true*/
/*global confirm:true*/
define([
    'jquery',
    'Magento_Ui/js/modal/modal',
    'jquery/ui',
], function($, modal){
    "use strict";
	
    $.widget('pf.sendfriend', {

        options: {
            element: null,
            modalOptions: {
                type: 'popup',
                responsive: true,
                innerScroll: true,
                responsiveClass: 'modal-popup',                
				modalClass: 'modal-sendfriend',
                buttons: [] 
            }
        },
        
          _create: function () {
            var self = this;
            this._super();
        },
        
        _init: function () {            
            if(this.options.element != null){
                $(document).on("click", this.options.element, this.openSendFriendPopUp.bind(this));
            }
            this._super();
        },

        openSendFriendPopUp: function(){
            var self = this;
            var popup = modal(self.options.modalOptions, $('#popup-modal-sf'));
            $('#popup-modal-sf').modal('openModal');
        }
    });
    
    return $.pf.sendfriend;
});