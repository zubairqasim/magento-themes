define([
    "jquery",
    'Magento_Catalog/js/price-box'
], function($) {
    'use strict';

    var regimenOptions = {
        container: '.box-regimen',
        baseAddToCartBtn: '#product-addtocart-button',
        regimenAddToCartBtn: '#add-all-to-cart',
        relatedProductsField: '#related-products-field',
        numberRegimenKeeper: '#number-regimen',
        basePriceKeeper: '.price-final_price[data-role="priceBox"]',
        regimenPriceKeeper: '#regimenPrice',
        checkboxItem: '.checkbox'
    };

    $.widget('regimen.js', {
        settings: regimenOptions,
        cache: {},

        /**
         * Widget initialisation.
         */
        _init: function initRegimen() {
            var self = this;
            $(this.settings.container).find(this.settings.checkboxItem).trigger('click');

            if (this.options.isProductInStock == '0') {
                $(this.settings.regimenAddToCartBtn).find('span').find('span').text('Out Of Stock');
                return;
            }
            $(this.settings.container).on('updateRegimen', this.updateRegimen());
            $(this.settings.regimenAddToCartBtn).removeClass('disabled');

            $('.product-options-wrapper').find('select[class="super-attribute-select"]').on('change', function (e) {
                setTimeout(function(){
                    $(self.settings.container).trigger('updateRegimen');
                }, 100);
            });
        },

        /**
         * Widget creating.
         */
        _create: function createRegimen() {
            $(this.settings.container).find(this.settings.checkboxItem).on('click', this.respondToRegimen());
            $(this.settings.regimenAddToCartBtn).on('click', this.addAllToCart());
        },

        respondToRegimen: function respondToRegimen() {
            var that = this;
            return function(e) {
                that.recountRegimenNumber();
                that.recountRegimenPrice();
                e.stopImmediatePropagation();
            };
        },

        updateRegimen: function() {
            var that = this;
            return function() {
                that.recountRegimenNumber();
                that.recountRegimenPrice();
            }
        },

        recountRegimenNumber: function recountRegimenNumber() {
            var regimenNumberKeeper = $(this.settings.numberRegimenKeeper);
            var regimenItems = $(this.settings.container).find(this.settings.checkboxItem);

            for (var i=0, counter=0, laps=regimenItems.size(); i<laps; i++) {
                if (regimenItems.eq(i).is(':checked')) {
                    counter++;
                }
            }

            regimenNumberKeeper.text(counter+1);
        },

        recountRegimenPrice: function recountRegimenPrice() {
            var basePriceKeeper = $(this.settings.basePriceKeeper).eq(0);
            var normalPriceKeeper = basePriceKeeper.find('span.price-container').find('span.price');
            var specialPriceKeeper = basePriceKeeper.find('span.special-price').find('span.price-container').find('span.price');
            var regimenPriceKeeper = $(this.settings.regimenPriceKeeper);
            var regimenItems = $(this.settings.container).find(this.settings.checkboxItem);
            var sum = (specialPriceKeeper.text() != "")
                ? this.convertData(specialPriceKeeper.text())
                : this.convertData(normalPriceKeeper.text())
            ;

            for (var i=0, laps=regimenItems.size(); i<laps; i++) {
                if (regimenItems.eq(i).is(':checked')) {
                    var itemSpecialPrice = regimenItems.eq(i).closest('.product-item-details').find('span.special-price').find('span.price-container').find('span').attr('data-price-amount');
                    var itemNormalPrice = regimenItems.eq(i).closest('.product-item-details').find('span.price-container').find('span').attr('data-price-amount');
                    if (itemNormalPrice == undefined) continue;
                    var itemPrice = (itemSpecialPrice != undefined) ? itemSpecialPrice : itemNormalPrice;
                    sum = sum + +itemPrice;
                }
            }

            regimenPriceKeeper.text(this.options.currency + Number(sum).toFixed(2));
        },

        addRelatedToForm: function addRelatedToForm() {
            var relatedFormField = $(this.settings.relatedProductsField);
            var regimenItems = $(this.settings.container).find(this.settings.checkboxItem);
            for (var i=0, related='', laps=regimenItems.size(); i<laps; i++) {
                if (regimenItems.eq(i).is(':checked')) {
                    if (isNaN(Number(regimenItems.eq(i).val()))) {
                        continue;
                    }
                    related = (related == '')
                        ? regimenItems.eq(i).val()
                        : related + ',' + regimenItems.eq(i).val()
                    ;
                }
            }
            relatedFormField.val(related);
        },

        clearRelatedFormField: function clearRelatedFormField() {
            $(this.settings.relatedProductsField).val('');
        },

        convertData: function converData(data) {
            return parseFloat(data.trim().replace('$', '').replace(',', ''));
        },

        addAllToCart: function addAllToCart() {
            var that = this;

            return function() {
                that.addRelatedToForm();
                $(that.settings.baseAddToCartBtn).trigger('click');
                that.clearRelatedFormField();
            };
        }

    });

    return $.regimen.js;
});
