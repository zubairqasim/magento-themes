/*
 * *
 *  Copyright © 2016 Magestore. All rights reserved.
 *  See COPYING.txt for license details.
 *
 */

define([
    'jquery',
    'mage/storage',
    'Magento_Customer/js/customer-data',
    'Magento_Checkout/js/model/quote',
    'Magento_Customer/js/action/check-email-availability',
    'Magento_Customer/js/model/customer',
    'mage/url',
    'mage/mage',
    'mage/validation',
    'jquery/ui',
], function ($, storage, localStorage,quote, checkEmailAvailability, customer, url) {
    $.widget("magestore.customerLogin", {
        options: {
            isEmailCheckComplete: null,
            isEmail: null
        },

        /**
         * customerLogin creation
         * @protected
         */

        _create: function () {
            var self = this, options = this.options;
            self.setEmailPassword();

            //alert('Welcome Hello World'+self.ValidateSubsciptionProduct());
            //if(self.ValidateSubsciptionProduct() == true && quote.guestEmail && self.getCookie('p2p_customer')!="") {
            //}

            $.extend(this, {
                $loginLinkControl: $('#onestepcheckout-login-link'),
                $forgotPasswordLink: $('#onestepcheckout-forgot-password-link'),
                $returnLoginLink: $('#onestepcheckout-return-login-link'),
                $registerLink: $('#onestepcheckout-register-link'),
                $returnLoginLinkFromRegister: $('#onestepcheckout-return-login-link-2'),

                $overlayControl: $('#control_overlay'),

                $loginButton: $('#onestepcheckout-login-button'),
                $registerButton: $('#onestepcheckout-register-button'),
                $sendPasswordButton: $('#onestepcheckout-forgot-button'),

                $loadingContol: $('#onestepcheckout-login-loading'),
                $forgotPasswordLoading: $('#onestepcheckout-forgot-loading'),
                $registerLoading: $('#onestepcheckout-register-loading'),

                $setPasswordLoading: $('#onestepcheckout-setapassword-loading'),
                $setPasswordError: $('#onestepcheckout-setapassword-error'),

                $loginError: $('#onestepcheckout-login-error'),
                $forgotPasswordError: $('#onestepcheckout-forgot-error'),
                $registerError: $('#onestepcheckout-register-error'),

                $forgotPasswordSuccess: $('#onestepcheckout-forgot-success'),

                $usernameInput: $('#id_onestepcheckout_username'),
                $passwordInput: $('#id_onestepcheckout_password'),


                $forgotPasswordContent: $('#onestepcheckout-login-popup-contents-forgot'),
                $setnewPasswordContent: $('#onestepcheckout-login-popup-contents-setapassword'),
                $loginContent: $('#onestepcheckout-login-popup-contents-login'),
                $registerContent: $('#onestepcheckout-login-popup-contents-register'),
                $forgotPasswordTitle: $('.title-forgot'),

                $closeButton: $('.close'),

                $loginPopup: $('#onestepcheckout-login-popup'),
                $emailForgot: $('#id_onestepcheckout_email'),

                $firstNameReg2: $('#id_onestepcheckout2_firstname'),
                $lastNameReg2: $('#id_onestepcheckout2_lastname'),

                $firstNameReg: $('#id_onestepcheckout_firstname'),
                $lastNameReg: $('#id_onestepcheckout_lastname'),
                $userNameReg: $('#id_onestepcheckout_register_username'),
                $passwordReg: $('#id_onestepcheckout_register_password'),
                $confirmReg: $('#id_onestepcheckout_register_confirm_password'),

                $passwordReg2: $('#id_onestepcheckout_setpassword'),
                $confirmReg2: $('#id_onestepcheckout_confirmpassword'),

                $loginTable: $('#onestepcheckout-login-table'),
                $forgotPasswordTable: $('#onestepcheckout-forgot-table'),
                $registerTable: $('#onestepcheckout-register-table'),

                $setPasswordContent: $('#onestepcheckout-login-popup-contents-setapassword')

            });

            this.$loginLinkControl.click(function () {
                self.resetFormLogin();
                $(self.element).show();
                self.$overlayControl.show();
            });

            this.$overlayControl.click(function () {
                if($overlayControl.hasClass('fixed')) {
                    return false;
                }
                self.$setPasswordContent.hide();
                self.$loginContent.show();
                $(self.element).hide();
                $(this).hide();
                $('#onestepcheckout-toc-popup').hide();
            });

            self.validateLoginForm();
            self.validateRegisterForm();
            self.validateForgotForm();
            self.validateRegisterGuestForm();

            //$(document).ready(function (e) {

            //}

            $(document).keypress(function (e) {

                if (e.which == 13) {
                    if (self.$loginContent.is(':visible')) {
                        $('#onestepcheckout-login-form').submit(function () {
                            return false;
                        });
                        self.validateLoginForm();
                    } else if (self.$forgotPasswordContent.is(':visible')) {
                        $('#onestepcheckout-register-form').submit(function () {
                            return false;
                        });
                        self.validateRegisterForm();
                    }
                    else if (self.$setnewPasswordContent.is(':visible')) {
                        $('#onestepcheckout-setapassword-form').submit(function () {
                            return false;
                        });
                        self.validateRegisterGuestForm();
                    } else if (self.$registerContent.is(':visible')) {
                        $('#onestepcheckout-forgot-form').submit(function () {
                            return false;
                        });
                        self.validateForgotForm();
                    }
                }
            });
            this.$forgotPasswordLink.click(function () {
                self.$loginContent.hide();
                self.$forgotPasswordContent.show();
            });

            this.$returnLoginLink.click(function () {
                self.$forgotPasswordContent.hide();
                self.$loginContent.show();
            });

            this.$registerLink.click(function () {
                self.$loginContent.hide();
                self.$loginPopup.addClass('absolute-box');
                self.$registerContent.show();
            });

            this.$returnLoginLinkFromRegister.click(function () {
                self.$registerContent.hide();
                self.$loginPopup.removeClass('absolute-box');
                self.$loginPopup.addClass('fixed-box');
                self.$loginContent.show();
            });

            this.$closeButton.click(function () {

                self.$forgotPasswordContent.hide();
                self.$registerContent.hide();
                self.$loginPopup.removeClass('absolute-box');
                self.$loginPopup.addClass('fixed-box');
                self.$setPasswordContent.hide();
                self.$loginContent.show();
                self.$loginPopup.hide();
                self.$overlayControl.hide();
                $('#onestepcheckout-toc-popup').hide();
            });

            $('#onestepcheckout-toc-link').click(function (e) {
                self.$overlayControl.show();
                e.preventDefault();
                $('#onestepcheckout-toc-popup').show();
            })

        },
        validateLoginForm: function () {
            var self = this;
            $('#onestepcheckout-login-form').mage('validation', {
                submitHandler: function (form) {
                    self.ajaxLogin();
                }
            });
        },

        setEmailPassword: function() {
            var self = this;

            if(self.ValidateSubsciptionProduct() == true && customer.isLoggedIn()== false && self.getCookie('p2p_customer_email')!="") {

                self.options.isEmailCheckComplete = $.Deferred();
                self.options.isEmail = self.getCookie('p2p_customer_email');

                //alert(self.options.isEmail);
                checkEmailAvailability(self.options.isEmailCheckComplete, self.options.isEmail);

                $.when(self.options.isEmailCheckComplete).done(function () {

                    this.ajaxCheckEmail(self.getCookie('p2p_customer_email')).done(function(data, textStatus, jqXHR){
                        if(data.success){
                            $('#onestepcheckout-login-popup').show().find('.onestepcheckout-popup-contents > div').hide().siblings('#onestepcheckout-login-popup-contents-login').show().find('#onestepcheckout-login-form')[0].reset();
                            $('#control_overlay').addClass('fixed').show();
                            $('#onestepcheckout-login-popup p.close').addClass('fixed');
                            $('#onestepcheckout-login-popup .social-buttons').hide();
                            $('#onestepcheckout-register-link').hide();
                            $('#customer-email-fieldset .note').remove();
                            $('body,html').animate({ scrollTop:0 }, 100);
                        }else{
                            $('#onestepcheckout-login-popup').show().find('.onestepcheckout-popup-contents > div').hide().siblings('#onestepcheckout-login-popup-contents-setapassword').show().find('#onestepcheckout-setapassword-form')[0].reset();
                            $('#control_overlay').addClass('fixed').show();
                            $('#onestepcheckout-login-popup p.close').addClass('fixed');
                            $('#onestepcheckout-login-popup .social-buttons').hide();
                            $('#onestepcheckout-register-link').hide();
                            $('#customer-email-fieldset .note').remove();
                            $('body,html').animate({ scrollTop:0 }, 100);
                        }
                    });

                }.bind(this)).fail(function () {

                    $('#onestepcheckout-login-popup').show();
                    $('#control_overlay').addClass('fixed').show();
                    $('#onestepcheckout-login-popup p.close').addClass('fixed');
                    $('#onestepcheckout-login-popup .social-buttons').hide();
                    $('#customer-email-fieldset .note').remove();
                    $('#onestepcheckout-register-link').hide();

                    $('body,html').animate({ scrollTop:0 }, 100);

                }.bind(this));


            }
        },

        ValidateSubsciptionProduct: function() {
            var quoteItems = quote.getItems(),
                quoteOption = false;

            for (var opt in quoteItems) {
                for(var i in quoteItems[opt].options) {
                    if(quoteItems[opt].options[i].value.indexOf('days') != -1) {
                        //alert(quoteItems[opt].options[i].value);
                        quoteOption = true;
                        break;
                    }
                }
            }
            return quoteOption;
        },
        getCookie: function(cookieName){
            var name = cookieName + "=";
            var decodedCookie = decodeURIComponent(document.cookie);
            var ca = decodedCookie.split(';');
            for(var i = 0; i <ca.length; i++) {
                var c = ca[i];
                while (c.charAt(0) == ' ') {
                    c = c.substring(1);
                }
                if (c.indexOf(name) == 0) {
                    return c.substring(name.length, c.length);
                }
            }
            return "";
        },
        validateRegisterForm: function () {
            var self = this;
            $('#onestepcheckout-register-form').mage('validation', {
                submitHandler: function (form) {
                    self.ajaxRegister();
                }
            });
        },
        validateRegisterGuestForm: function () {
            var self = this;
            $('#onestepcheckout-setapassword-form').mage('validation', {
                submitHandler: function (form) {
                    self.ajaxGuestRegister();
                }
            });
        },
        setCookie: function(cookieName, cookieValue, cookieExpDays){
            var d = new Date();
            d.setTime(d.getTime() + (cookieExpDays*24*60*60*1000));
            var expires = "expires="+ d.toUTCString();
            document.cookie = cookieName + "=" + cookieValue + ";" + expires + ";path=/";
        },
        validateForgotForm: function () {
            var self = this;
            $('#onestepcheckout-forgot-form').mage('validation', {
                submitHandler: function (form) {
                    self.ajaxForgotPassword();
                }
            });
        },

        ajaxGuestRegister: function () {
            //console.log(quote.shippingAddress());
            //console.log("=====");
            //console.log(quote.shippingAddress().firstname);
            //console.log(quote.shippingAddress().lastname);

            //console.log("=====");
            //console.log(quote.paymentMethod());
            console.log("=====");
            console.log(quote.guestEmail);

            //return false;

            var self = this, options = this.options;
            if (self.$passwordReg2.val() == self.$confirmReg2.val()) {
                self.$setPasswordLoading.show();
                self.$registerTable.hide();
                self.$setPasswordError.hide();
                var params = {
                    firstname: self.$firstNameReg2.val(),
                    lastname: self.$lastNameReg2.val(),
                    email: self.getCookie('p2p_customer_email'),
                    /*postcode:quote.shippingAddress().postcode,
                    city:quote.shippingAddress().city,
                    telephone:quote.shippingAddress().telephone,
                    street:quote.shippingAddress().street[0],
                    street2:quote.shippingAddress().street[1],
                    regionid:quote.shippingAddress().regionId,
                    company:quote.shippingAddress().company,*/
                    password: self.$passwordReg2.val(),
                    password_confirmation: self.$confirmReg2.val()
                };
                //return false;
                storage.post(
                    'checkout/index/guestCreation',
                    JSON.stringify(params),
                    false
                ).done(
                    function (result) {
                        var sections = ['cart','checkout-data','customer'];
                        localStorage.invalidate(sections);
                        localStorage.reload(sections, true);
                        self.$setPasswordLoading.hide();
                        var success = result.success;
                        if (!result.error) {
                            self.setShippingAddressFromData({});
                            self.setCookie('autorp',1,1);
                            window.location.reload();
                        } else {
                            self.$registerTable.show();
                            self.$setPasswordError.html(result.error);
                            self.$setPasswordError.show();
                        }
                    }
                ).fail(
                    function (result) {

                    }
                );
            } else {
                alert("Please Re-Enter Confirmation Password !");
            }
        },
        ajaxLogin: function () {
            var self = this, options = this.options;
            self.$loadingContol.show();
            self.$loginTable.hide();
            self.$loginError.hide();
            var params = {
                username: self.$usernameInput.val(),
                password: self.$passwordInput.val()
            };
            storage.post(
                'checkout/index/login',
                JSON.stringify(params),
                false
            ).done(
                function (result) {
                    var sections = ['cart','checkout-data','customer'];
                    localStorage.invalidate(sections);
                    localStorage.reload(sections, true);
                    var errors = result.errors;
                    if (errors == false) {
                        self.$loadingContol.show();
                        self.setShippingAddressFromData({});
                        window.location.reload();
                    } else {
                        self.$loadingContol.hide();
                        self.$loginTable.show();
                        self.$loginError.html(result.message);
                        self.$loginError.show();
                    }
                }
            ).fail(
                function (result) {

                }
            );
        },

        setShippingAddressFromData: function (data) {
            var cacheKey = 'checkout-data';
            var obj = localStorage.get(cacheKey)();
            obj.shippingAddressFromData = data;
            localStorage.set(cacheKey, obj);
        },

        ajaxRegister: function () {
            var self = this, options = this.options;
            if (self.$passwordReg.val() == self.$confirmReg.val()) {
                self.$registerLoading.show();
                self.$registerTable.hide();
                self.$registerError.hide();
                var params = {
                    firstname: self.$firstNameReg.val(),
                    lastname: self.$lastNameReg.val(),
                    email: self.$userNameReg.val(),
                    password: self.$passwordReg.val(),
                    password_confirmation: self.$confirmReg.val()
                };
                storage.post(
                    'onestepcheckout/account/register',
                    JSON.stringify(params),
                    false
                ).done(
                    function (result) {
                        var sections = ['cart','checkout-data','customer'];
                        localStorage.invalidate(sections);
                        localStorage.reload(sections, true);
                        self.$registerLoading.hide();
                        var success = result.success;
                        if (!result.error) {
                            self.setShippingAddressFromData({});
                            window.location.reload();
                        } else {
                            self.$registerTable.show();
                            self.$registerError.html(result.error);
                            self.$registerError.show();
                        }
                    }
                ).fail(
                    function (result) {

                    }
                );
            } else {
                alert("Please Re-Enter Confirmation Password !");
            }
        },
        ajaxForgotPassword: function () {
            var self = this, options = this.options;
            self.$forgotPasswordError.hide();
            self.$forgotPasswordLoading.show();
            self.$forgotPasswordTable.addClass('fixit').hide();
            var params = {
                email: self.$emailForgot.val()
            };
            storage.post(
                'checkout/index/forgotPassword',
                JSON.stringify(params),
                false
            ).done(
                function (result) {
                    self.$forgotPasswordLoading.hide();
                    var success = result.success;
                    if (success == 'true') {
                        self.$forgotPasswordSuccess.show();
                        self.$forgotPasswordTable.addClass('fixit').hide();
                        self.$forgotPasswordTitle.hide();
                    } else {
                        self.$forgotPasswordTable.removeClass('fixit').show();
                        self.$forgotPasswordError.html(result.errorMessage);
                        self.$forgotPasswordError.show();
                    }
                }
            ).fail(
                function (result) {

                }
            );
        },
        ajaxCheckEmail: function (email) {
            var getUrl = url.build('StockFile/TestCron/CheckEmail?');

            return $.ajax({
                url: getUrl,
                dataType: 'JSON',
                type: 'GET',
                data: {email: email},
                showLoader: true,
            });
        },
        resetFormLogin: function () {
            var self = this;
            self.$loginTable.show();
            self.$forgotPasswordTable.removeClass('fixit').show();
            self.$registerTable.show();

            self.$loadingContol.hide();
            self.$forgotPasswordLoading.hide();
            self.$registerLoading.hide();

            self.$loginError.hide();
            self.$forgotPasswordError.hide();
            self.$registerError.hide();

            self.$loginContent.show();
            self.$forgotPasswordContent.hide();
            self.$registerContent.hide();
        }
    });

    return $.magestore.customerLogin;
});
