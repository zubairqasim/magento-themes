

define([
    'jquery',
    'mage/translate'
], function ($, $t) {
    'use strict';
	
	var mixin = {
		/**
         * Get Braintree Hosted Fields
         * @returns {Object}
         */
        getHostedFields: function () {
            var self = this,
                fields = {
                    number: {
                        selector: self.getSelector('cc_number')
                    },
                    expirationDate: {
                        selector: self.getSelector('expirationDate'),
                        placeholder: $t('MM/YYYY')
                    }
                };

            if (self.hasVerification()) {
                fields.cvv = {
                    selector: self.getSelector('cc_cid')
                };
            }

            return fields;
        }
    };

    return function (target) {
        return target.extend(mixin);
    };
});
