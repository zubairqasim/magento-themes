var config = {
	config: {
        mixins: {
            'PayPal_Braintree/js/view/payment/method-renderer/hosted-fields': {
                'PayPal_Braintree/js/view/payment/method-renderer/hosted-fields-mixin': true
            },
        }
    }
};