var config = {
    config: {
        mixins: {
            'Amasty_Shopby/js/amShopbyAjax': {
                'Amasty_Shopby/js/amShopbyAjax-mixin': true
            },
        }
    }
};
