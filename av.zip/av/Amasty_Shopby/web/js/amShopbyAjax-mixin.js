define([
    'jquery',
    'jquery/ui'
], function ($) {
    'use strict';

    return function (widget) {
        $.widget('mage.amShopbyAjax', widget, {
			callAjax: function (clearUrl, data, pushState, cacheKey, isSorting, isGetCounter) {
				var self = this;
				self._super(clearUrl, data, pushState, cacheKey, isSorting, isGetCounter);

				/**
				 * Cdigital
				 *
				 * Yotpo Initialization
				 */
				if (!clearUrl) {
					clearUrl = self.options.clearUrl;
				}
				clearUrl = clearUrl.replace(/amp;/g, '');
				self.clearUrl = clearUrl;
				console.warn('callAjax Url: ' + clearUrl);
				$(document).ajaxComplete(function(event,xhr,settings){
					if(settings.url.indexOf(clearUrl) !== -1 ) {
						console.warn('callAjax Complete');
                        yotpo.initWidgets();
						// if( typeof yotpo !== 'undefined'){
						// 	console.warn('callAjax Yotpo');
						// 	var yotpoInit = new Yotpo (yotpo.appKey, { userSettings: yotpo.userSettings });
						// 	Yotpo.ready(function() {
						// 		console.warn('callAjax Yotpo Ready');
						// 		yotpoInit.init();
						// 		console.warn('callAjax Yotpo Init');
						// 	});
						// }
					}
				});
			},
        });

        return $.mage.amShopbyAjax;
    }
});
